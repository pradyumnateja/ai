import os
import numpy as np
from LogisticRegression import LogisticRegression

# 2.1 Logistic Regression Training
X_train_1, X_test_1 = np.load('../Data1/X_train.npy'), np.load('../Data1/X_test.npy')
X_train_2, X_test_2 = np.load('../Data2/X_train.npy'), np.load('../Data2/X_test.npy')
X_train_3, X_test_3 = np.load('../Data3/X_train.npy'), np.load('../Data3/X_test.npy')
y_train, y_test = np.load('../Data3/y_train.npy'), np.load('../Data3/y_test.npy')

lr1 = LogisticRegression()
lr1.fit(X_train_1, y_train)

lr2 = LogisticRegression()
lr2.fit(X_train_2, y_train)

lr3 = LogisticRegression()
lr3.fit(X_train_3, y_train)

lr1.save('../Data1/LogisticRegression')
lr2.save('../Data2/LogisticRegression')
lr3.save('../Data3/LogisticRegression')