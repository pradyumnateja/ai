import os
import numpy as np

# 2.1 Logistic Regression
class LogisticRegression:
    
    def __init__(self, Epochs=1000, Number_of_Classes=[0, 1, 2]):
        self.Epochs = Epochs
        self.Number_of_Classes = Number_of_Classes
    
    # fit method fits a model, pre-processes data, initializes weights
    # Then trains using batch gradient descent with specified batch size and learning rate
    def fit(self, X, y, batch_size=32, lr=0.01):
        self.Number_of_Classes = np.unique(y)
        self.class_labels = {c:i for i,c in enumerate(self.Number_of_Classes)}
        X = self.AddBias(X)
        y = self.OneHot(y)
        self.loss = []
        self.weights = np.zeros(shape=(len(self.Number_of_Classes),X.shape[1]))
        self.fit_batch(X, y, batch_size, lr)
        return self
 
    # The fit_batch method fits the model based on batch gradient descent with cross-entropy loss
    # and updating weights using a random batch of samples.
    def fit_batch(self, X, y, batch_size, lr):
        i = 0
        while (i < self.Epochs):
            self.loss.append(self.CrossEntropy(y, self.predict_prob(X)))
            idx = np.random.choice(X.shape[0], batch_size)
            X_batch, y_batch = X[idx], y[idx]
            error = y_batch - self.predict_prob(X_batch)
            self.weights += lr * np.dot(error.T, X_batch)
            i += 1
    
    # Below step is used in linear models to account for the intercept term.
    def predict_(self, X):
        return self.predict_prob(self.AddBias(X))
    
    # predict probabilities function predict probabilities of each class for the given input features X.
    def predict_prob(self, X):
        y_predict = np.dot(X, self.weights.T).reshape(-1, len(self.Number_of_Classes))
        return self.Soft_Max_Activation(y_predict)
    
    # softmax activation function is commonly used in multi-class classification problems to convert raw scores into a probability distribution over multiple classes.
    def Soft_Max_Activation(self, z):
        return np.exp(z) / np.sum(np.exp(z), axis=1).reshape(-1,1)
    
    def predict(self, X):
        self.probs_ = self.predict_(X)
        return np.vectorize(lambda c: self.Number_of_Classes[c])(np.argmax(self.probs_, axis=1))
    
    def score(self, X, y):
        return np.mean(self.predict(X) == y)
    
    def evaluate_(self, X, y):
        return np.mean(np.argmax(self.predict_prob(X), axis=1) == np.argmax(y, axis=1))
    
    # Adding a bias term is necessary when working with linear models to allow for shifting of the model's predictions
    def AddBias(self,X):
        return np.insert(X, 0, 1, axis=1)

    # OneHot function is a encoding on a given set of class labels y. 
    # One-hot encoding is a ML process for categorical variables.
    # And each category is represented as a binary vector indicating the presence or absence of that category.
    def OneHot(self, y):
        return np.eye(len(self.Number_of_Classes))[np.vectorize(lambda c: self.class_labels[c])(y).reshape(-1)]
    
    # Below CrossEntropy function gives cross-entropy loss between the true labels y and the predicted probabilities(probs).
    def CrossEntropy(self, y, probs):
        return -1 * np.mean(y * np.log(probs))
    
    # save function is to save the model's parameters (Weights and bias) to disk in the specified location.
    def save(self, model_path):
        np.save(f"{model_path}/weights.npy", self.weights)
    
    # load function is to load the weights and biases of a model from the specified directory path.
    def load(self, model_path):
        self.weights = np.load(f"{model_path}/weights.npy")
        