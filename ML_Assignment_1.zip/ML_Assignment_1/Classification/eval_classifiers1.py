import os
import numpy as np
import matplotlib.pyplot as plt
from mlxtend.plotting.decision_regions import plot_decision_regions
from Logistic_Regression.LogisticRegression import LogisticRegression

# 2.2 Testing
data = 'Data_1'
X_test = np.load(f'{data}/X_test.npy')
y_test = np.load(f'{data}/y_test.npy')

lr = LogisticRegression()
lr.load(f'{data}/LogisticRegression')


fig, ax = plt.subplots(1, 1)
ax = plot_decision_regions(X_test, y_test, lr)
ax.set_title(f'Logistic Regression for {data}')
plt.savefig(f'{data}/LogisticRegression/decision_region.png')

print(f'For {data} Accuracy Logistic Regression : {lr.score(X_test, y_test)}')