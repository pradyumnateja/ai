import os
import numpy as np
from sklearn import datasets
from sklearn.model_selection import train_test_split

# Loading the data
# Preparing the Data
iris = datasets.load_iris()
data = iris.data # 2D Array
target = iris.target # 0,1,2

# train_test_split: split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(data, target, test_size=0.1, stratify=target)

X_train_1, X_test_1 = X_train[:, [2]], X_test[:, [2]] # petal length
X_train_2, X_test_2 = X_train[:, [0]], X_test[:, [0]] # sepal length
X_train_3, X_test_3 = X_train.copy(), X_test.copy() # All features

if not os.path.exists('Data_1'): 
    os.mkdir('Data_1')
if not os.path.exists('Data_2'):
    os.mkdir('Data_2')
if not os.path.exists('Data_3'):
    os.mkdir('Data_3')

# save is to save the model's parameters (Weights and bias) to disk in the specified location.
np.save('Data_1/X_train.npy', X_train_1), np.save('Data_1/X_test.npy', X_test_1), np.save('Data_1/y_train.npy', y_train), np.save('Data_1/y_test.npy', y_test)
np.save('Data_2/X_train.npy', X_train_2), np.save('Data_2/X_test.npy', X_test_2), np.save('Data_2/y_train.npy', y_train), np.save('Data_2/y_test.npy', y_test) 
np.save('Data_3/X_train.npy', X_train_3), np.save('Data_3/X_test.npy', X_test_3), np.save('Data_3/y_train.npy', y_train), np.save('Data_3/y_test.npy', y_test) 