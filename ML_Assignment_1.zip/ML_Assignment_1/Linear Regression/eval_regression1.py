import os
import numpy as np
from LinearRegression import LinearRegression


name = "Linear_Regression_1"

# Loading the test data
X_test, y_test = np.load(f"{name}/X_test.npy"), np.load(f"{name}/y_test.npy")

lr = LinearRegression()
lr.load(name)

mse = lr.score(X_test, y_test)
print(f'The MSE for {name} is {mse}')