import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split
from LinearRegression import LinearRegression

# Loading the data
# Preparing the Data
iris = datasets.load_iris()
data = iris.data # 2D Array
target = iris.target # 0,1,2

# Features - sepal length, sepal width, petal length, petal width

X = data[:, [0]] # sepal length
y = data[:, 1] # sepal width

# Train and test split
# train_test_split: split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)

# Regression model
epochs = 100
batch_size = 32
lr = LinearRegression()
# Loading the pretrained weights of Linear_Regression_1
lr.load('Linear_Regression_1')

lr_regularisation = LinearRegression()
lr_regularisation.fit(X_train, y_train, batch_size=batch_size, regularization=0.4, max_epochs=epochs)


print(f'Without regularisation weights: {lr.weights, lr.bias}')
print(f'With regularisation weights: {lr_regularisation.weights, lr_regularisation.bias}')
