import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split
from LinearRegression import LinearRegression

# Loading the data
# Preparing the Data
iris = datasets.load_iris()
data = iris.data # 2D Array
target = iris.target # 0,1,2

# Features: sepal length, sepal width, petal length, petal width

X = data[:, [0]] # sepal length and 2D Array
y = data[:, 1] # sepal width and 1D Array

# Train and Test split
# train_test_split: split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)

epochs = 100
batch_size = 32
lr = LinearRegression()
lr.fit(X_train, y_train, batch_size=batch_size, regularization=0, max_epochs=epochs)

name = 'Linear_Regression_1'
if not os.path.exists(name):
    os.mkdir(name)

np.save(f'{name}/X_test.npy', X_test)
np.save(f'{name}/y_test.npy', y_test)

# Saving the file with the given name from the above
lr.save(name)

# Plotting and saving the training loss
plt.plot(list(range(len(lr.train_loss))), lr.train_loss)
plt.xlabel("Epoch")  # X-axis label
plt.ylabel("Train Loss")  # Y-axis label
plt.title(f"{name}")
plt.savefig(f'{name}/Train_Loss.png')
