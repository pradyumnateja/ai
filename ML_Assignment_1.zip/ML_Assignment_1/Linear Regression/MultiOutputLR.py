import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split

# Loading the data
# Preparing the Data
iris = datasets.load_iris()
data = iris.data # 2D Array
target = iris.target # 0,1,2

# Features - sepal length, sepal width, petal length, petal width

X = data[:, [0, 1]] # sepal length, sepal width
y = data[:, [2, 3]] # petal length, petal width

# Train and test split
# train_test_split: split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1)

#  Creating the LR model with multiple outputs
class MultiOutputLinearRegression:
    def __init__(self, L_Rate=0.01):
        self.L_Rate = L_Rate
        self.train_loss = []

    def fit(self, X, y, max_epochs=100, batch_size=32):
        self.max_epochs = max_epochs
        self.batch_size = batch_size
        m, n = X.shape
        num_targets = y.shape[1]

        self.weights = np.zeros((n, num_targets))
        self.bias = np.zeros(num_targets)

        for epoch in range(self.max_epochs):
            indexs = np.arange(m)
            np.random.shuffle(indexs)
            total_loss = 0.0

            for i in range(0, m, self.batch_size):
                batch_indices = indexs[i:i + self.batch_size]
                X_batch = X[batch_indices]
                y_batch = y[batch_indices]

                y_pred = np.dot(X_batch, self.weights) + self.bias
                
                dw = (1 / self.batch_size) * np.dot(X_batch.T, (y_pred - y_batch))
                db = (1 / self.batch_size) * np.sum(y_pred - y_batch, axis=0)
                self.weights -= self.L_Rate * dw
                self.bias -= self.L_Rate * db

                # Mean Sqaured Error
                batch_loss = np.mean((y_pred - y_batch) ** 2)
                total_loss += batch_loss

            # finding the loss
            avg_loss = total_loss / (m)
            self.train_loss.append(avg_loss)

            print(f"Epoch {epoch + 1} | Training loss: {avg_loss}")

    def predict(self, X):
        # The Below line of code computes the predictions of a linear regression model
        output = np.dot(X, self.weights) + self.bias
        return output

    def score(self, X, y):
        # It is used to compute the mean squared error between the true target values (y) and the predicted target values (y_pred) for a given set of input features (X).
        y_pred = self.predict(X)
        mse = np.mean((y_pred - y) ** 2)
        return mse

    # 1.4 Saving the model
    def save(self, model_path):
        np.save(f"{model_path}/weights.npy", self.weights)
        np.save(f"{model_path}/biases.npy", self.bias)
        
    # 1.5 Loading the model
    def load(self, model_path):
        self.weights = np.load(f"{model_path}/weights.npy")
        self.bias = np.load(f"{model_path}/biases.npy")

print("Training Started")
# Regression model
epochs = 100
batch_size = 32
multioutput_lr = MultiOutputLinearRegression()
multioutput_lr.fit(X_train, y_train, batch_size=batch_size, max_epochs=epochs)
print("Training Finished")


print(f"The train r2 score is : {multioutput_lr.score(X_train, y_train)}")
print(f"The test r2 score is : {multioutput_lr.score(X_test, y_test)}")


name = "Multi Output LR"
if not os.path.exists(name):
       os.mkdir(name)

# Plotting and saving the training loss
plt.plot(list(range(len(multioutput_lr.train_loss))), multioutput_lr.train_loss)
plt.xlabel("epoch")  #X-axis label
plt.ylabel("train loss")  #Y-axis label
plt.title(f"{name}")  #title
plt.savefig(f'{name}/train_loss.png')