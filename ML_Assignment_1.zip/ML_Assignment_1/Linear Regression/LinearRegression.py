import numpy as np

# Regularization is a technique used in machine learning to prevent overfitting by adding a penalty term to the loss function. 
class LinearRegression:
    def __init__(self, batch_size=32, regularization=0, max_epochs=100, patience=3):
        self.batch_size = batch_size
        self.regularization = regularization
        self.max_epochs = max_epochs
        self.patience = patience
        self.weightseights = None
        self.bias = None
    
    # 1.2 The Fit Method
    # Learning rate determines the magnitude of the adjustments made to the parameters in each iteration of the optimization algorithm
    # Patience default "3"
    def fit(self, X, y, batch_size=32, regularization=0, max_epochs=100, patience=3, L_Rate=0.01):
        self.batch_size = batch_size
        self.regularization = regularization
        self.max_epochs = max_epochs
        self.patience = patience
        self.L_Rate = L_Rate

        # TODO: Initialize the weights and bias based on the shape of X and y.
        # Initialization of Random Weights
        self.weights,self.bias = np.random.rand(X.shape[1]),np.random.rand(1)
        
        # Randomly shuffeling
        a = np.random.permutation(len(X))
        X = X[a]
        y = y[a]
        
        # Training and validation loss
        self.train_loss = []
        self.val_loss = []
        
        data_size = X.shape[0]
        # selecting 10% of the data for validation
        X_train, X_val = X[:int(data_size*0.9), :], X[int(data_size*0.9):, :]
        y_train, y_val = y[:int(data_size*0.9)], y[int(data_size*0.9):]
        
        # Splitting the training data X_train into batches using NumPy's array_split function
        Batch_X = np.array_split(X_train, self.batch_size) 
        Batch_Y = np.array_split(y_train, self.batch_size)
        
        for i in range(1, self.max_epochs+1):
            Loss_Batch = []
            # It pairs the corresponding elements from both lists(X_Batch,Y_Batch) together at each iteration using the zip() function.
            for X_Batch, Y_Batch in zip(Batch_X, Batch_Y):
                self.update_weights(X_Batch, Y_Batch)
                Y_Batch_Pred = self.predict(X_Batch)
                Loss_Batch.append(self.mse(Y_Batch, Y_Batch_Pred))
            # It represents the average loss across all batches for the current epoch
            self.train_loss.append(np.mean(Loss_Batch))
            Y_Val_Pred = self.predict(X_val)
            
            self.val_loss.append(self.mse(y_val, Y_Val_Pred))
            
            # Patience Checking
            # If it is > 3 stop training
            out = self.patience_check()
            if i>self.patience and not out:
                break
    
    def update_weights(self, X, Y):
        n, _ = X.shape
        Y_pred = self.predict(X)
          
        # Finding the gradients
        # This code calculates the gradients of the weights (dW) and bias (db) for a linear regression model with regularization   
        Gradient_Weights = (-(2*(X.T).dot(Y - Y_pred)) +               
               (2*self.regularization*self.weights))/n     
        Gradient_Bias = -2*np.sum(Y-Y_pred )/n 
          
        # Updating Weights and Bias
        self.weights = self.weights - self.L_Rate*Gradient_Weights    
        self.bias = self.bias- self.L_Rate*Gradient_Bias        
        return self    
    
    # 1.3 The Predict Method
    def predict(self, X):
        # The Below line of code computes the predictions of a linear regression model
        return X.dot(self.weights) + self.bias

    # 1.4 The Score Method
    # It is used to compute the mean squared error between the true target values (y) and the predicted target values (y_pred) for a given set of input features (X).
    def score(self, X, y):
        y_pred = self.predict(X)
        return self.mse(y, y_pred)
    
    def patience_check(self):
        val_loss = self.val_loss[-self.patience:]
        out = all(i>j for i, j in zip(val_loss, val_loss[1:]))
        return out
    
    def mse(self, y_gt, y_pred):
        # Mean Square Error Formula
        # It is a metric used to measure the average squared difference between the actual values and the predicted values in a regression problem.
        return ((y_gt-y_pred)**2).mean()
    
    # 1.5 Saving the model
    # save method is to save the model's parameters (Weights and bias) to disk in the specified location.
    def save(self, model_path):
        np.save(f"{model_path}/weights.npy", self.weights)
        np.save(f"{model_path}/biases.npy", self.bias)
        
    # 1.5 Loading the model
    # load method is designed to load the weights and biases of a model from the specified directory path.
    def load(self, model_path):
        self.weights = np.load(f"{model_path}/weights.npy")
        self.bias = np.load(f"{model_path}/biases.npy")
