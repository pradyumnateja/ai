import sys

RED_MULTIPLIER = 2
BLUE_MULTIPLIER = 3

class RedBlueNim:
    def __init__(self, num_red, num_blue, first_player, depth=None):
        self.num_red = num_red
        self.num_blue = num_blue
        self.current_player = first_player
        self.depth = depth

    def play(self):
        while self.num_red > 0 and self.num_blue > 0:
            if self.current_player == 'computer':
                pile = self.find_best_move()
                print(f"Computer removes marble from {pile} pile.")
                self.remove_marbles(pile,1)
                self.current_player = 'human'
            else:
                print("Current state:")
                print(f"Red pile: {self.num_red}")
                print(f"Blue pile: {self.num_blue}")
                pile = input("Enter the pile you want to remove marble(s) from (red/blue): ")
                self.remove_marbles(pile,1)
                self.current_player = 'computer'
        print("Game over!")
        if self.num_red == 0:
            print("Computer wins!")
            print(f"Final score: {self.num_blue * BLUE_MULTIPLIER}")
        else:
            print("Human wins!")
            print(f"Final score: {self.num_red * RED_MULTIPLIER}")

    def find_best_move(self):
        if self.depth < 0:
            best_value, best_pile = self.minmax_ab(0, float('-inf'), float('inf'), True)
        else:
            best_value = float('-inf')
            best_pile = None
            for pile, count in [('red', self.num_red), ('blue', self.num_blue)]:
                for i in range(1, count + 1):
                    new_count = count - i
                    if pile == 'red':
                        value = new_count * RED_MULTIPLIER
                    else:
                        value = new_count * BLUE_MULTIPLIER
                    if value > best_value:
                        best_value = value
                        best_pile = pile
        return best_pile

    def minmax_ab(self, depth, alpha, beta, is_max):
        if depth == 0 or self.num_red == 0 or self.num_blue == 0:
            return self.eval_board()
        
        if is_max:
            max_value = float('-inf')
            for pile, count in [('red', self.num_red), ('blue', self.num_blue)]:
                for i in range(1, count + 1):
                    new_count = count - i
                    if pile == 'red':
                        value = new_count * RED_MULTIPLIER
                    else:
                        value = new_count * BLUE_MULTIPLIER
                    self.remove_marbles(pile, 1)
                    max_value = max(max_value, self.minmax_ab(depth - 1, alpha, beta, False) + value)
                    alpha = max(alpha, max_value)
                    self.add_marbles(pile, 1)
                    if beta <= alpha:
                        break
            return max_value
        else:
            min_value = float('inf')
            for pile, count in [('red', self.num_red), ('blue', self.num_blue)]:
                for i in range(1, count + 1):
                    new_count = count - i
                    if pile == 'red':
                        value = new_count * RED_MULTIPLIER
                    else:
                        value = new_count * BLUE_MULTIPLIER
                    self.remove_marbles(pile, 1)
                    min_value = min(min_value, self.minmax_ab(depth - 1, alpha, beta, True) - value)
                    beta = min(beta, min_value)
                    self.add_marbles(pile, 1)
                    if beta <= alpha:
                        break
            return min_value
        
    def add_marbles(self, pile, count):
        if pile == 'red':
            self.num_red += count
        else:
            self.num_blue += count

    def remove_marbles(self, pile, count):
        if pile == 'red':
            self.num_red -= count
        else:
            self.num_blue -= count

    def eval_board(self):
        if self.num_red == 0:
            return float('-inf')
        elif self.num_blue == 0:
            return float('inf')
        else:
            return (self.num_red * RED_MULTIPLIER) - (self.num_blue * BLUE_MULTIPLIER)


if __name__ == '__main__':
    num_red = int(sys.argv[1])
    num_blue = int(sys.argv[2])
    first_player = 'computer' if len(sys.argv) < 4 or sys.argv[3] == 'computer' else 'human'
    depth = 4 if len(sys.argv) < 5 else int(sys.argv[4])
    game = RedBlueNim(num_red, num_blue, first_player, depth)
    game.play()