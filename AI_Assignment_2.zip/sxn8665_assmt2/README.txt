# Red Blue Nim Game - README file

## Student Information
Name: Satya Pradyumna Teja Nunna
UTA ID: 1002028665

## Programming Language Used
The programming language used for this task is python.

## Code Structure
The code is structured into 1 file:
*nim_alpha_beta.py:* This is the main program that should be run from the command line with arguments for the game.

##Code Explaination

--> play method will run as long as either piles have atleast 1 marble
--> find_best_move will find the next best possible move based on number of marbles available in piles
--> minmax_ab will do minimizing or maximizing of depths(computer is maximizing player and human is minimizing player)
--> eval_board method returns the score of the current state of the board, where a positive score means that the current state is better for the maximizing player, and a negative score means that the current state is better for the minimizing player. The score is determined by subtracting the current value of the blue pile multiplied by 3 from the current value of the red pile multiplied by 2

## How to Run the Code
To run the code, follow the steps below:
-- Open the command line or terminal and navigate to the directory containing the nim_alpha_beta.py file. 
-- Run the command:

python nim_alpha_beta.py 7 8 'human' 6

where:
first argument : num_red is the number of red marbles in the game.
second_argument : num_blue is the number of blue marbles in the game.
third_argument : first_player is the player that starts the game. This can be either 'computer' or 'human'.
fourth_argument : depth is an optional argument that determines the depth of the minmax search algorithm. If not specified, the algorithm will use its default value (4).

Follow the prompts to play the game.

## ACS Omega
This code has not been tested on ACS Omega.

## Resources used
- https://www.hackerearth.com/blog/developers/minimax-algorithm-alpha-beta-pruning/
- https://www.cs.cornell.edu/courses/cs312/2004fa/hw/ps4/ps4.htm
- https://realpython.com/python-minimax-nim/