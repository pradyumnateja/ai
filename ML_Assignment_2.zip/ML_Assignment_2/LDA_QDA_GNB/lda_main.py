from utils import load_and_prepare_data

# LDAModel: It provides tools for extracting topics from text data, facilitating clustering, categorization, and insight discovery.
from models import LDAModel

# numpy: Importing the numpy library in Python is a common step when working with numerical operations, arrays, and mathematical functions.
import numpy as np

# Load and preprocess the data
print("Loading data...", end="")
# load and prepare some data, presumably related to images.
# Then assigning the returned values to variables X_train_rgb, y_train_rgb, X_test_rgb, and y_test_rgb.
# as_grayscale=False as opposes to grayscale images.
X_train_rgb, y_train_rgb, X_test_rgb, y_test_rgb = load_and_prepare_data(
    as_grayscale=False
)
# load and prepare some data, presumably related to images.
# Then assigning the returned values to variables X_train_rgb, y_train_rgb, X_test_rgb, and y_test_rgb.
# as_grayscale=True Agree to grayscale images.
X_train_gray, y_train_gray, X_test_gray, y_test_gray = load_and_prepare_data(
    as_grayscale=True
)
print("done.")

# Initialize and fit LDA for RGB version
print("Fitting LDA RGB model...", end="")
lda_rgb = LDAModel()
# lda_rgb.fit(X_train_rgb, y_train_rgb) fits the model to the training data.
# X_train_rgb is the training dataset of RGB images, and y_train_rgb is the corresponding array of labels or classes for those images.
lda_rgb.fit(X_train_rgb, y_train_rgb)
print("done.")

# Make predictions for RGB version
print("Making predictions on LDA RGB Model...")
# lda_rgb.predict(X_test_rgb) uses the trained LDA model lda_rgb to predict the labels for the test RGB images X_test_rgb.
predictions_rgb = lda_rgb.predict(X_test_rgb)
# It calculates the accuracy by comparing the predicted labels predictions_rgb to the actual labels y_test_rgb.
accuracy_rgb = np.mean(predictions_rgb == y_test_rgb)
print("Accuracy on RGB version:", accuracy_rgb)


# Initialize and fit LDA for Grayscale version
print("Fitting LDA Grayscale model...", end="")
lda_gray = LDAModel()
# lda_gray.fit(X_train_gray, y_train_gray) fits the model to the training data.
# X_train_gray is the training dataset of gray images, and y_train_gray is the corresponding array of labels or classes for those images.
lda_gray.fit(X_train_gray, y_train_gray)
print("done.")

# Make predictions for Grayscale version
print("Making predictions on LDA Grayscale Model...")
# lda_gray.predict(X_test_gray) uses the trained LDA model lda_gray to predict the labels for the test RGB images X_test_gray.
predictions_gray = lda_gray.predict(X_test_gray)
# It calculates the accuracy by comparing the predicted labels predictions_gray to the actual labels y_test_gray.
accuracy_gray = np.mean(predictions_gray == y_test_gray)
print("Accuracy on Grayscale version:", accuracy_gray)
