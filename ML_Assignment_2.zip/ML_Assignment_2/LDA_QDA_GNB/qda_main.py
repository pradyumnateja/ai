from utils import load_and_prepare_data

# QDAModel: it allows for non-linear separation between classes.
# QDA assumes that the data from each class is normally distributed and estimates a quadratic decision boundary
from models import QDAModel

# numpy: Importing the numpy library in Python is a common step when working with numerical operations, arrays, and mathematical functions.
import numpy as np

# Load and preprocess the data
print("Loading data...", end="")
# load and prepare some data, presumably related to images.
# Then assigning the returned values to variables X_train_rgb, y_train_rgb, X_test_rgb, and y_test_rgb.
# as_grayscale=False as opposes to grayscale images.
X_train_rgb, y_train_rgb, X_test_rgb, y_test_rgb = load_and_prepare_data(
    as_grayscale=False
)
# load and prepare some data, presumably related to images.
# Then assigning the returned values to variables X_train_rgb, y_train_rgb, X_test_rgb, and y_test_rgb.
# as_grayscale=True Agree to grayscale images.
X_train_gray, y_train_gray, X_test_gray, y_test_gray = load_and_prepare_data(
    as_grayscale=True
)
print("done.")

# Initialize and fit QDA for RGB version
print("Fitting QDA RGB model...", end="")
qda_rgb = QDAModel()
# qda_rgb.fit(X_train_rgb, y_train_rgb) fits the model to the training data.
# X_train_rgb is the training dataset of RGB images, and y_train_rgb is the corresponding array of labels or classes for those images.
qda_rgb.fit(X_train_rgb, y_train_rgb)
print("done.")

# Make predictions for RGB version
print("Making predictions on QDA RGB Model...")
# qda_rgb.predict(X_test_rgb) uses the trained qda model qda_rgb to predict the labels for the test RGB images X_test_rgb.
predictions_rgb = qda_rgb.predict(X_test_rgb)
# It calculates the accuracy by comparing the predicted labels predictions_rgb to the actual labels y_test_rgb.
accuracy_rgb = np.mean(predictions_rgb == y_test_rgb)
print("Accuracy on RGB version:", accuracy_rgb)


# Initialize and fit QDA for Grayscale version
print("Fitting QDA Grayscale model...", end="")
qda_gray = QDAModel()
# qda_gray.fit(X_train_gray, y_train_gray) fits the model to the training data.
# X_train_gray is the training dataset of gray images, and y_train_gray is the corresponding array of labels or classes for those images.
qda_gray.fit(X_train_gray, y_train_gray)
print("done.")

# Make predictions for Grayscale version
print("Making predictions on QDA Grayscale Model...")
# qda_gray.predict(X_test_gray) uses the trained qda model qda_gray to predict the labels for the test RGB images X_test_gray.
predictions_gray = qda_gray.predict(X_test_gray)
# It calculates the accuracy by comparing the predicted labels predictions_gray to the actual labels y_test_gray.
accuracy_gray = np.mean(predictions_gray == y_test_gray)
print("Accuracy on Grayscale version:", accuracy_gray)
