from utils import load_and_prepare_data

# GaussianNBModel: GaussianNB is suitable for classification tasks and assumes that the features follow a Gaussian (normal) distribution.
from models import GaussianNBModel

# numpy: Importing the numpy library in Python is a common step when working with numerical operations, arrays, and mathematical functions.
import numpy as np

# Load and preprocess the data
print("Loading data...", end="")
# load and prepare some data, presumably related to images.
# Then assigning the returned values to variables X_train_rgb, y_train_rgb, X_test_rgb, and y_test_rgb.
# as_grayscale=False as opposes to grayscale images.
X_train_rgb, y_train_rgb, X_test_rgb, y_test_rgb = load_and_prepare_data(
    as_grayscale=False
)
# load and prepare some data, presumably related to images.
# Then assigning the returned values to variables X_train_rgb, y_train_rgb, X_test_rgb, and y_test_rgb.
# as_grayscale=True Agree to grayscale images.
X_train_gray, y_train_gray, X_test_gray, y_test_gray = load_and_prepare_data(
    as_grayscale=True
)
print("done.")

# Initialize and fit nb for RGB version
print("Fitting GaussianNBModel RGB model...", end="")
gnb_rgb = GaussianNBModel()
# nb_rgb.fit(X_train_rgb, y_train_rgb) fits the model to the training data.
# X_train_rgb is the training dataset of RGB images, and y_train_rgb is the corresponding array of labels or classes for those images.
gnb_rgb.fit(X_train_rgb, y_train_rgb)
print("done.")

# Make predictions for RGB version
print("Making predictions on GaussianNBModel RGB Model...")
# nb_rgb.predict(X_test_rgb) uses the trained nb model nb_rgb to predict the labels for the test RGB images X_test_rgb.
predictions_rgb = gnb_rgb.predict(X_test_rgb)
# It calculates the accuracy by comparing the predicted labels predictions_rgb to the actual labels y_test_rgb.
accuracy_rgb = np.mean(predictions_rgb == y_test_rgb)
print("Accuracy on RGB version:", accuracy_rgb)


# Initialize and fit GaussianNBModel for Grayscale version
print("Fitting GaussianNBModel Grayscale model...", end="")
gnb_gray = GaussianNBModel()
# nb_gray.fit(X_train_gray, y_train_gray) fits the model to the training data.
# X_train_gray is the training dataset of gray images, and y_train_gray is the corresponding array of labels or classes for those images.
gnb_gray.fit(X_train_gray, y_train_gray)
print("done.")

# Make predictions for Grayscale version
print("Making predictions on GaussianNBModel Grayscale Model...")
# nb_gray.predict(X_test_gray) uses the trained nb model nb_gray to predict the labels for the test RGB images X_test_gray.
predictions_gray = gnb_gray.predict(X_test_gray)
# It calculates the accuracy by comparing the predicted labels predictions_gray to the actual labels y_test_gray.
accuracy_gray = np.mean(predictions_gray == y_test_gray)
print("Accuracy on Grayscale version:", accuracy_gray)
