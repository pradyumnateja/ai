import numpy as np


class LDAModel:
    def fit(self, X_train, y_train):
        if len(X_train.shape) == 4:  # RGB images
            num_samples, height, width, channels = X_train.shape
            X_train_flattened = X_train.reshape(num_samples, height * width * channels)
        elif len(X_train.shape) == 3:  # Grayscale images
            num_samples, height, width = X_train.shape
            X_train_flattened = X_train.reshape(num_samples, height * width)
        else:
            raise ValueError("Invalid shape for X_train. Expected 3D or 4D array.")

        num_classes = np.max(y_train) + 1
        X_train_with_bias = np.concatenate(
            (np.ones((num_samples, 1)), X_train_flattened), axis=-1
        )
        y_train_encoded = np.eye(num_classes)[
            y_train
        ]  # One-hot encode y_train directly
        self.weights = (
            np.linalg.inv(X_train_with_bias.T @ X_train_with_bias)
            @ X_train_with_bias.T
            @ y_train_encoded
        )

    def predict(self, X_test):
        if len(X_test.shape) == 4:  # RGB images
            num_samples, height, width, channels = X_test.shape
            X_test_flattened = X_test.reshape(num_samples, height * width * channels)
        elif len(X_test.shape) == 3:  # Grayscale images
            num_samples, height, width = X_test.shape
            X_test_flattened = X_test.reshape(num_samples, height * width)
        else:
            raise ValueError("Invalid shape for X_test. Expected 3D or 4D array.")

        X_test_with_bias = np.concatenate(
            (np.ones((num_samples, 1)), X_test_flattened), axis=-1
        )
        predicted_scores = self.weights.T @ X_test_with_bias.T
        return np.argmax(predicted_scores, axis=0)


class QDAModel:
    def fit(self, X, y):
        if len(X.shape) == 4:  # RGB images
            num_samples, height, width, channels = X.shape
            X = X.reshape(num_samples, height * width * channels)
        elif len(X.shape) == 3:  # Grayscale images
            num_samples, height, width = X.shape
            X = X.reshape(num_samples, height * width)
        else:
            raise ValueError("Invalid shape for X_train. Expected 3D or 4D array.")

        self.classes = np.unique(y)
        self.means = []
        self.inverse_covariances = []
        self.log_coefficients = []

        for c in self.classes:
            X_c = X[y == c]
            mean = np.mean(X_c, axis=0)
            covariance = np.cov(X_c.T) + 1e-4 * np.identity(X.shape[1])
            inverse_covariance = np.linalg.inv(covariance)
            self.means.append(mean)
            self.inverse_covariances.append(inverse_covariance)
            log_coefficient = -0.5 * (
                len(mean) * np.log(2 * np.pi) + np.linalg.slogdet(covariance)[1]
            )
            self.log_coefficients.append(log_coefficient)

    def predict(self, X):
        if len(X.shape) == 4:  # RGB images
            num_samples, height, width, channels = X.shape
            X = X.reshape(num_samples, height * width * channels)
        elif len(X.shape) == 3:  # Grayscale images
            num_samples, height, width = X.shape
            X = X.reshape(num_samples, height * width)
        else:
            raise ValueError("Invalid shape for X_test. Expected 3D or 4D array.")

        predictions = []
        for x in X:
            discriminants = []
            for mean, inverse_covariance, log_coefficient in zip(
                self.means, self.inverse_covariances, self.log_coefficients
            ):
                # Calculate the quadratic discriminant function
                exponent = -0.5 * (x - mean) @ inverse_covariance @ (x - mean).T
                discriminant = log_coefficient + exponent
                discriminants.append(discriminant)
            predictions.append(self.classes[np.argmax(discriminants)])
        return np.array(predictions)


class GaussianNBModel:
    def fit(self, X, y):
        self.classes = np.unique(y)
        self.class_prior = []
        self.means = []
        self.variances = []

        for c in self.classes:
            X_c = X[y == c]
            self.class_prior.append(len(X_c) / len(X))
            self.means.append(np.mean(X_c, axis=0))
            self.variances.append(np.var(X_c, axis=0))

    def predict(self, X):
        predictions = []
        for x in X:
            posteriors = []
            for i, c in enumerate(self.classes):
                prior = np.log(self.class_prior[i])
                mean = self.means[i]
                variance = self.variances[i]

                # Calculate the log likelihood
                log_likelihood = -0.5 * np.sum(
                    np.log(2 * np.pi * variance) + (x - mean) ** 2 / variance
                )

                # Calculate the posterior (log posterior)
                posterior = prior + log_likelihood
                posteriors.append(posterior)
            predictions.append(self.classes[np.argmax(posteriors)])
        return np.array(predictions)
