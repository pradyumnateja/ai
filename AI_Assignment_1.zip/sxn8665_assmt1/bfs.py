from queue import Queue

class Class_Puzzle_node:
    def __init__(self, Class_State, Class_Parent=None, Class_Move=None):
        self.Class_State = Class_State
        self.Class_Parent = Class_Parent
        self.Class_Move = Class_Move
        if Class_Parent is None:
            self.Class_Depth = 0
        else:
            self.Class_Depth = Class_Parent.Class_Depth + 1
    def __str__(self):
        return str(self.Class_State)
    def __repr__(self):
        return str(self.Class_State)
    def __eq__(self, other):
        return self.Class_State == other.Class_State
    def __hash__(self):
        return hash(str(self.Class_State))

def Func_get_Successors(node):
    List_Of_Successors = []
    Temp_Loop_I, Temp_Loop_J = node.Class_State.index(0) // 3, node.Class_State.index(0) % 3
    if Temp_Loop_I > 0:
        Class_State = node.Class_State[:]
        Class_State[Temp_Loop_I*3+Temp_Loop_J], Class_State[(Temp_Loop_I-1)*3+Temp_Loop_J] = Class_State[(Temp_Loop_I-1)*3+Temp_Loop_J], Class_State[Temp_Loop_I*3+Temp_Loop_J]
        List_Of_Successors.append(Class_Puzzle_node(Class_State, node, 'Up'))
    if Temp_Loop_I < 2:
        Class_State = node.Class_State[:]
        Class_State[Temp_Loop_I*3+Temp_Loop_J], Class_State[(Temp_Loop_I+1)*3+Temp_Loop_J] = Class_State[(Temp_Loop_I+1)*3+Temp_Loop_J], Class_State[Temp_Loop_I*3+Temp_Loop_J]
        List_Of_Successors.append(Class_Puzzle_node(Class_State, node, 'Down'))
    if Temp_Loop_J > 0:
        Class_State = node.Class_State[:]
        Class_State[Temp_Loop_I*3+Temp_Loop_J], Class_State[Temp_Loop_I*3+Temp_Loop_J-1] = Class_State[Temp_Loop_I*3+Temp_Loop_J-1], Class_State[Temp_Loop_I*3+Temp_Loop_J]
        List_Of_Successors.append(Class_Puzzle_node(Class_State, node, 'Left'))
    if Temp_Loop_J < 2:
        Class_State = node.Class_State[:]
        Class_State[Temp_Loop_I*3+Temp_Loop_J], Class_State[Temp_Loop_I*3+Temp_Loop_J+1] = Class_State[Temp_Loop_I*3+Temp_Loop_J+1], Class_State[Temp_Loop_I*3+Temp_Loop_J]
        List_Of_Successors.append(Class_Puzzle_node(Class_State, node, 'Right'))
    return List_Of_Successors

def breadth_first_search(Arg_Start, Arg_Goal, status):
    
    tracing_data = "" + "Input Data ->\n" + str(Arg_Start) + "\noutput data ->\n" + str(Arg_Goal) + "\n\n" + "Choosen Algorithm -> Breadth First Search\n" 
    
    Main_Start_Node = Class_Puzzle_node(Arg_Start)
    Main_Goal_Node = Class_Puzzle_node(Arg_Goal)
    Total_Nodes_Popped = 0
    Total_Nodes_Expand = 0
    Total_Nodes_Generated = 0
    Maximu_Frienze_Size = 0
    Main_Frontier = Queue()
    Main_Frontier.put(Main_Start_Node)
    Explored_Nodes = set()
    
    #
    tracing_data = tracing_data + "\n" + "Starting Search"
    tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Total_Nodes_Popped)
    tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Total_Nodes_Expand)
    tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Total_Nodes_Generated)
    tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Maximu_Frienze_Size)
    
    while not Main_Frontier.empty():
        Maximu_Frienze_Size = max(Maximu_Frienze_Size, Main_Frontier.qsize())
        node = Main_Frontier.get()
        Total_Nodes_Popped += 1
        if node == Main_Goal_Node:
            Total_Steps_taken = []
            while node.Class_Parent is not None:
                Total_Steps_taken.append(node.Class_Move)
                node = node.Class_Parent
            Total_Steps_taken.reverse()
            Step_Count = 1
            Cost_Estimation = 0
            
            #
            tracing_data = tracing_data + "\n" + "\n\nFinal Move ->"
            tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Total_Nodes_Popped)
            tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Total_Nodes_Expand)
            tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Total_Nodes_Generated)
            tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Maximu_Frienze_Size)
            
            print("Nodes Popped ->", Total_Nodes_Popped)
            print("Nodes Expanded ->", Total_Nodes_Expand)
            print("Nodes Generated ->", Total_Nodes_Generated)
            print("Max Fringe Size ->", Maximu_Frienze_Size)
            print("Solution Found at Depth", len(Total_Steps_taken))
            Arg_Start = [Arg_Start[:3], Arg_Start[3:6], Arg_Start[6:]]
            print("Steps:")
            for Each_Value in Total_Steps_taken:
                Each_Value = Each_Value.title().strip()
                Position_Of_Zero = [None, None]
                for i in range(3):
                    for j in range(3):
                        if Arg_Start[i][j] == 0:
                            Position_Of_Zero = [ i, j]
                            break
                
                if Each_Value == "Left":
                    Temp_Cost = int(Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]-1])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Right")
                    Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]], Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]-1] = Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]-1], Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]]
                    #if status == "true" : print(Arg_Start)
                elif Each_Value == "Right":
                    Temp_Cost = int(Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]+1])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Left")
                    Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]], Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]+1] = Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]+1], Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]]
                    #if status == "true" : print(Arg_Start)
                elif Each_Value == "Up":
                    Temp_Cost = int(Arg_Start[Position_Of_Zero[0]-1][Position_Of_Zero[1]])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Down")
                    Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]], Arg_Start[Position_Of_Zero[0]-1][Position_Of_Zero[1]] = Arg_Start[Position_Of_Zero[0]-1][Position_Of_Zero[1]], Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]]
                    #if status == "true" : print(Arg_Start)
                elif Each_Value == "Down":
                    Temp_Cost = int(Arg_Start[Position_Of_Zero[0]+1][Position_Of_Zero[1]])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Up")
                    Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]], Arg_Start[Position_Of_Zero[0]+1][Position_Of_Zero[1]] = Arg_Start[Position_Of_Zero[0]+1][Position_Of_Zero[1]], Arg_Start[Position_Of_Zero[0]][Position_Of_Zero[1]]
                    #if status == "true" : print(Arg_Start)
                Step_Count = Step_Count + 1
            print("Final Cost :", Cost_Estimation)
            
            if status=="true":
                file = open("Tracing Dumps", "w")
                file.writelines(tracing_data)
                file.close()
            
            return
        
        #
        tracing_data = tracing_data + "\n" + "Adding to Explored ->" + str(node)
        
        Explored_Nodes.add(node)
        
        #
        tracing_data = tracing_data + "\n" + "Generating all possible moves ->"
        
        for Loop_Successor in Func_get_Successors(node):
            
            #
            tracing_data = tracing_data + "\n" + "Move ->" + str(Loop_Successor)
            
            if Loop_Successor not in Explored_Nodes and Loop_Successor not in Main_Frontier.queue:
                Total_Nodes_Generated += 1
                Main_Frontier.put(Loop_Successor)
                
                #
                tracing_data = tracing_data + "\n" + "Move not in explored ------"
                tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Total_Nodes_Generated)
        
        Total_Nodes_Expand += 1
        
        #
        tracing_data = tracing_data + "\n" + "- - - - - -- - - - - - "
        tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Total_Nodes_Popped)
        tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Total_Nodes_Expand)
        tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Total_Nodes_Generated)
        tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Maximu_Frienze_Size)
        
        tracing_data = tracing_data + "\n"
    print("No solution found.")


