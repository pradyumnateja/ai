import heapq
import copy

def heuristic(Board_State, ins_Goal_State):
    cost = 0
    for Loop_I in range(3):
        for Loop_J in range(3):
            if Board_State[Loop_I][Loop_J] != ins_Goal_State[Loop_I][Loop_J]:
                cost += 1
    return cost

def dfs_a_star(start_state, ins_Goal_State):
    
    tracing_data = "" + "Input Data ->\n" + str(start_state) + "\noutput data ->\n" + str(ins_Goal_State) + "\n\n" + "Choosen Algorithm -> A Star Search\n" 
    
    Popped_Nodes = 0
    Expan_Node = 0
    Gen_Nodes = 0
    Max_Frienge_Size = 0
    Visi_Node = set()
    fringe = [(heuristic(start_state, ins_Goal_State), 0, start_state, [])]
    
    #
    tracing_data = tracing_data + "\n" + "Starting Search"
    tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Popped_Nodes)
    tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Expan_Node)
    tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Gen_Nodes)
    tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Max_Frienge_Size)
    tracing_data = tracing_data + "\n" + "fringe  -> " + str(fringe)
    
    while fringe:
        (f, g, Board_State, path) = heapq.heappop(fringe)
        Popped_Nodes += 1
        if Board_State == ins_Goal_State:
            tracing_data = tracing_data + "\n" + "Reached Destination --"
            tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Popped_Nodes)
            tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Expan_Node)
            tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Gen_Nodes)
            tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Max_Frienge_Size)
            return (Popped_Nodes, Expan_Node, Gen_Nodes, Max_Frienge_Size, g, path, tracing_data)
        List_of_Successors = []
        Loop_I, Loop_J = next((Loop_I, Loop_J) for Loop_I in range(3) for Loop_J in range(3) if Board_State[Loop_I][Loop_J] == 0)
        if Loop_I > 0:
            successor_state = copy.deepcopy(Board_State)
            successor_state[Loop_I][Loop_J], successor_state[Loop_I-1][Loop_J] = successor_state[Loop_I-1][Loop_J], successor_state[Loop_I][Loop_J]
            List_of_Successors.append(successor_state)
        if Loop_I < 2:
            successor_state = copy.deepcopy(Board_State)
            successor_state[Loop_I][Loop_J], successor_state[Loop_I+1][Loop_J] = successor_state[Loop_I+1][Loop_J], successor_state[Loop_I][Loop_J]
            List_of_Successors.append(successor_state)
        if Loop_J > 0:
            successor_state = copy.deepcopy(Board_State)
            successor_state[Loop_I][Loop_J], successor_state[Loop_I][Loop_J-1] = successor_state[Loop_I][Loop_J-1], successor_state[Loop_I][Loop_J]
            List_of_Successors.append(successor_state)
        if Loop_J < 2:
            successor_state = copy.deepcopy(Board_State)
            successor_state[Loop_I][Loop_J], successor_state[Loop_I][Loop_J+1] = successor_state[Loop_I][Loop_J+1], successor_state[Loop_I][Loop_J]
            List_of_Successors.append(successor_state)
        
        
        tracing_data = tracing_data + "\n" + "Board State ->" + str(Board_State)
        tracing_data = tracing_data + "\n" + "List of Successors ->" + str(List_of_Successors)
        for successor in List_of_Successors:
            tracing_data = tracing_data + "\n" + "Printing Successor ->" + str(successor)
            if str(successor) not in Visi_Node:
                tracing_data = tracing_data + "\n" + "Successor Not in Visited Nodes"
                Visi_Node.add(str(successor))
                Gen_Nodes += 1
                tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Gen_Nodes)
                successor_path = path + [successor]
                heapq.heappush(fringe, (heuristic(successor, ins_Goal_State) + g + 1, g + 1, successor, successor_path))
            
            tracing_data = tracing_data + "\n"
        Expan_Node += 1
        Max_Frienge_Size = max(Max_Frienge_Size, len(fringe))
        tracing_data = tracing_data + "\n" + "After Iteration --"
        tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Popped_Nodes)
        tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Expan_Node)
        tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Gen_Nodes)
        tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Max_Frienge_Size)
    return (Popped_Nodes, Expan_Node, Gen_Nodes, Max_Frienge_Size, -1, [], tracing_data)

