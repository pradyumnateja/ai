class Class_Node:
    def __init__(self, Get_State, get_parent=None, get_move=None, get_depth=0):
        self.Get_State = Get_State
        self.get_parent = get_parent
        self.get_move = get_move
        self.get_depth = get_depth
    def __eq__(self, other):
        return self.Get_State == other.Get_State
    def __lt__(self, other):
        return self.Get_State < other.Get_State
    def __str__(self):
        return str(self.Get_State)
    def __repr__(self):
        return str(self.Get_State)
    def __hash__(self):
        return hash(str(self.Get_State))

def get_move(Get_State, direction):
    new_state = Get_State.copy()
    index = new_state.index(0)
    if direction == 'up':
        if index not in range(0, 3):
            temp = new_state[index-3]
            new_state[index-3] = new_state[index]
            new_state[index] = temp
            return new_state
    elif direction == 'down':
        if index not in range(6, 9):
            temp = new_state[index+3]
            new_state[index+3] = new_state[index]
            new_state[index] = temp
            return new_state
    elif direction == 'left':
        if index not in range(0, 9, 3):
            temp = new_state[index-1]
            new_state[index-1] = new_state[index]
            new_state[index] = temp
            return new_state
    elif direction == 'right':
        if index not in range(2, 9, 3):
            temp = new_state[index+1]
            new_state[index+1] = new_state[index]
            new_state[index] = temp
            return new_state
    return None

def depth_limited_search(initial_state_to_go, goal_state, dep_limi):
    
    tracing_data = "" + "Input Data ->\n" + str(initial_state_to_go) + "\noutput data ->\n" + str(goal_state) + "\n\n" + "Choosen Algorithm -> Breadth First Search\n" 
    
    E_Pop = 0
    E_Exp = 0
    E_Gen = 1
    Max_F_Size = 0
    initial_node = Class_Node(initial_state_to_go)
    Max_Fringe = [initial_node]
    set_exp = set()
    
    #
    tracing_data = tracing_data + "\n" + "Starting Search"
    tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(E_Pop)
    tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(E_Exp)
    tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(E_Gen)
    tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Max_F_Size)
    
    while Max_Fringe:
        if len(Max_Fringe) > Max_F_Size:
            Max_F_Size = len(Max_Fringe)
        Active_node = Max_Fringe.pop()
        E_Pop += 1
        if Active_node.Get_State == goal_state:
            path = []
            Cost_Est = Active_node.get_depth
            while Active_node.get_parent is not None:
                path.append(Active_node.get_move)
                Active_node = Active_node.get_parent
            path.reverse()
            
            tracing_data = tracing_data + "\n\n" + "Final Data Search"
            tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(E_Pop)
            tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(E_Exp)
            tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(E_Gen)
            tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Max_F_Size)
            
            return E_Pop, E_Exp, E_Gen, Max_F_Size, Cost_Est, path, tracing_data
        if Active_node.get_depth < dep_limi:
            set_exp.add(Active_node)
            E_Exp += 1
            tracing_data = tracing_data + "\n" +  "Parent State ->" + str(Active_node.Get_State)
            tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(E_Pop)
            tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(E_Exp)
            tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(E_Gen)
            tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Max_F_Size)
            for direction in ['up', 'down', 'left', 'right']:
                child_state = get_move(Active_node.Get_State, direction)
                tracing_data = tracing_data + "\n" + "Direction ->" + direction + "Child State Generated ->" + str(child_state)
                if child_state is not None:
                    getting_child_node = Class_Node(child_state, get_parent=Active_node, get_move=direction, get_depth=Active_node.get_depth+1)
                    E_Gen += 1
                    if getting_child_node not in set_exp and getting_child_node not in Max_Fringe:
                        tracing_data = tracing_data + "\n" + "Chils satete is not in visited"
                        tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(E_Pop)
                        tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(E_Exp)
                        tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(E_Gen)
                        tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Max_F_Size)
                        Max_Fringe.append(getting_child_node)
        tracing_data = tracing_data + "\n\n" + "After Iteration Search"
        tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(E_Pop)
        tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(E_Exp)
        tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(E_Gen)
        tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Max_F_Size) + "\n"
    return E_Pop, E_Exp, E_Gen, Max_F_Size, -1, None, tracing_data

