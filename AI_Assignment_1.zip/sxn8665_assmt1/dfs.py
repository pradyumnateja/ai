class Main_node:
    def __init__(self, Current_State, Current_Parent, Current_Action, Current_Depth, Current_Cost):
        self.Current_State = Current_State
        self.Current_Parent = Current_Parent
        self.Current_Action = Current_Action
        self.Current_Depth = Current_Depth
        self.Current_Cost = Current_Cost
    def __eq__(self, other):
        return self.Current_State == other.Current_State
    def __lt__(self, other):
        return self.Current_Cost < other.Current_Cost

def Active_Successor(Current_State):
    Active_Successor = []
    Loop_I = Current_State.index(0)
    if Loop_I not in [0, 1, 2]:
        new_state = list(Current_State)
        new_state[Loop_I], new_state[Loop_I - 3] = new_state[Loop_I - 3], new_state[Loop_I]
        Active_Successor.append(("Move {} Up".format(Current_State[Loop_I - 3]), tuple(new_state), 1))
    if Loop_I not in [6, 7, 8]:
        new_state = list(Current_State)
        new_state[Loop_I], new_state[Loop_I + 3] = new_state[Loop_I + 3], new_state[Loop_I]
        Active_Successor.append(("Move {} Down".format(Current_State[Loop_I + 3]), tuple(new_state), 1))
    if Loop_I not in [0, 3, 6]:
        new_state = list(Current_State)
        new_state[Loop_I], new_state[Loop_I - 1] = new_state[Loop_I - 1], new_state[Loop_I]
        Active_Successor.append(("Move {} Left".format(Current_State[Loop_I - 1]), tuple(new_state), 1))
    if Loop_I not in [2, 5, 8]:
        new_state = list(Current_State)
        new_state[Loop_I], new_state[Loop_I + 1] = new_state[Loop_I + 1], new_state[Loop_I]
        Active_Successor.append(("Move {} Right".format(Current_State[Loop_I + 1]), tuple(new_state), 1))
    return Active_Successor

def dfs(Instance_State, Goaling_State):
    
    #
    tracing_data = "" + "Input Data ->\n" + str(Instance_State) + "\noutput data ->\n" + str(Goaling_State) + "\n\n" + "Choosen Algorithm -> Depth First Search\n" 
    
    Front_node = [Main_node(Instance_State, None, None, 0, 0)]
    Exp_node = set()
    Pop_Node = 0
    Exp_Node = 0
    Max_fri = 1
    while Front_node:
        Max_fri = max(Max_fri, len(Front_node))
        Active_node = Front_node.pop()
        Pop_Node += 1
        if Active_node.Current_State == Goaling_State:
            solution_path = []
            while Active_node.Current_Parent is not None:
                solution_path.append(Active_node.Current_Action)
                Active_node = Active_node.Current_Parent
            solution_path.reverse()
            
            #
            tracing_data = tracing_data + "\n" + "\n\nFinal Move ->"
            tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str((Pop_Node))
            tracing_data = tracing_data + "\n" + "Total Nodes generated ->" + str((Pop_Node + Exp_Node))
            tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Exp_node)
            tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Max_fri)
            tracing_data = tracing_data + "\n" + "Current depth -> " + str(len(solution_path))
            
            return {"success": True, "Pop_Node": Pop_Node, "Exp_Node": Exp_Node, "nodes_generated": Pop_Node + Exp_Node, "Max_fri": Max_fri, "Current_Depth": len(solution_path), "Current_Cost": Active_node.Current_Cost, "solution_path": solution_path, "trace": tracing_data}
        Exp_node.add(Active_node.Current_State)
        
        #
        tracing_data = tracing_data + "\n" + "\n\n Iterative Move Move ->" + str(Active_node.Current_State)
        tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str((Pop_Node))
        tracing_data = tracing_data + "\n" + "Total Nodes generated ->" + str((Pop_Node + Exp_Node))
        tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Exp_node)
        tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Max_fri)
        
        for Current_Action, Current_State, Current_Cost in Active_Successor(Active_node.Current_State):
            tracing_data = tracing_data + "\n" + str(Current_State)
            tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str((Pop_Node))
            tracing_data = tracing_data + "\n" + "Total Nodes generated ->" + str((Pop_Node + Exp_Node))
            tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Exp_node)
            tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Max_fri)
            
            if Current_State not in Exp_node:
                Front_node.append( Main_node(Current_State, Active_node, Current_Action, Active_node.Current_Depth + 1, Active_node.Current_Cost + Current_Cost) )
                tracing_data = tracing_data + "\n" + "Move not in Expanded"
                tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Exp_node)
                Exp_Node = Exp_Node + 1
            
            tracing_data = tracing_data + "\n"
            
    return {"success": False}


