Name:Satya Pradyumna Teja Nunna
UTA ID:1002028665

The programming language used is python. Version :Python 3.9.13

The code is structured in way that all the search algorithms are written seperately in a .py file
and all are called from the main file based on the given parameters.

Run the code using command prompt  by opening cmd in the folder and after opening the cmd
give the following command :python 8puzzleproblem.py start.txt goal.txt [algorithm name] true.
Make sure all the files are in the same folder/directory to not get any issues.

To give the startfile and goal for testing my code please put the name as start.txt and goal as 
goal.txt in the same folder for testing .

Alogrithm Names:
a*
bfs
dfs
ids
dls
ucs
greedy