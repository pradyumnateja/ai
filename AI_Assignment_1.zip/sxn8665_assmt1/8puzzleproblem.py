import sys

def Find_Blank(Main_Board):
    for i in range(3):
        for j in range(3):
            if Main_Board[i][j] == 0:
                return i, j

def Direction_Trace(solution, Selected_Dump_Status):
    Step_Counting = 1
    Length_Solution = len(solution)-1
    Total_Cost = 0
    for Temp_Index_value in range(Length_Solution):
        #if Selected_Dump_Status == "true":
            #print("Step ->", Step_Counting)
        first_zer_pos = Find_Blank(solution[Temp_Index_value])
        second_zer_pos = Find_Blank(solution[Temp_Index_value + 1])
        Temp_Cost = solution[Temp_Index_value][second_zer_pos[0]][second_zer_pos[1]]
        Total_Cost = Total_Cost + Temp_Cost
        if first_zer_pos[0] == second_zer_pos[0]:
            if first_zer_pos[1] > second_zer_pos[1]:
                print("\tMove", Temp_Cost, "Right")
            else:
                print("\tMove", Temp_Cost, "Left")
        else:
            if first_zer_pos[0] > second_zer_pos[0]:
                print("\tMove", Temp_Cost, "Down")
            else:
                print("\tMove", Temp_Cost, "Up")
        #if Selected_Dump_Status == "true":
                #print(solution[Temp_Index_value+1])
        Step_Counting = Step_Counting + 1
    print("Final Cost :", Total_Cost)


Readin_Input_File = ""
Readin_Goal_File = ""
Selected_Search = "a*"
Selected_Dump_Status = "false"
Line_Arg = sys.argv
Len_Line_Arg = len(Line_Arg)
if Len_Line_Arg >= 3:
    
    Readin_Input_File = Line_Arg[1]
    Readin_Goal_File = Line_Arg[2]
    
    if Len_Line_Arg >= 4:
        Selected_Search = Line_Arg[3].lower()
    
    if Len_Line_Arg == 5:
        Selected_Dump_Status = Line_Arg[4]
    
    Getting_files = open(Readin_Input_File, 'r')
    Getting_files_Data = [ x.replace("\n","").strip().split(" ") for x in Getting_files.readlines() ][:-1]
    Input_File_Read = [ [ int(y) for y in x] for x in Getting_files_Data]
    
    Getting_files = open(Readin_Goal_File, 'r')
    Getting_files_Data = [ x.replace("\n","").strip().split(" ") for x in Getting_files.readlines() ][:-1]
    Goal_File_Read = [ [ int(y) for y in x] for x in Getting_files_Data]
    
    if Input_File_Read == "" or Goal_File_Read == "":
        print("Please write proper data in input or goal file!")
        sys.exit()
        
    if Selected_Search == "bfs":
        print("Breadth First Search")
        from bfs import breadth_first_search
        main_input = []
        for x in Input_File_Read:
            main_input.extend(x)
        Arg_Goal = []
        for x in Goal_File_Read:
            Arg_Goal.extend(x)
        breadth_first_search(main_input, Arg_Goal, Selected_Dump_Status)
        
    elif Selected_Search == "ucs":
        print("Uniform Total_Cost Search")
        from ucs import uniform_cost_search
        uniform_cost_search(Input_File_Read, Goal_File_Read, Selected_Dump_Status)
        
    elif Selected_Search == "dfs":
        
        print("Depth First Search")
        from dfs import dfs
        initial_state = []
        for x in Input_File_Read:
            initial_state.extend(x)
        goal_state = []
        for x in Goal_File_Read:
            goal_state.extend(x)
        result = dfs(tuple(initial_state), tuple(goal_state))
        tracing_data = result['trace']
        if result["success"]:
            print("Nodes Popped ->", result["Pop_Node"])
            print("Nodes Expanded ->", result["Exp_Node"])
            print("Nodes Generated ->", result["Pop_Node"] + result["Exp_Node"])
            print("Max Fringe Size ->", result["Max_fri"])
            print("Solution Found at Current_Depth", result["Current_Depth"])
            print("Steps:")
            Cost = 0
            for step in result["solution_path"]:
                Cost = Cost + int(step.strip().split(" ")[1])
                print("\t", step)
            print("Final Cost ->", Cost)
        else:
            print("No solution found.")
        
        if Selected_Dump_Status=="true":
            file = open("Tracing Dumps", "w")
            file.writelines(tracing_data)
            file.close()
        
    elif Selected_Search == "dls":
        print("Depth Limited Search")
        from dls import depth_limited_search
        initial_state_to_go = []
        for x in Input_File_Read:
            initial_state_to_go.extend(x)
        goal_state = []
        for x in Goal_File_Read:
            goal_state.extend(x)
        dep_limi = int(input("kindly enter the depth limit ->"))
        status = Selected_Dump_Status
        E_Pop, E_Exp, E_Gen, Max_F_Size, Cost_Est, path, tracing_data = depth_limited_search(initial_state_to_go, goal_state, dep_limi)
        print("Nodes Popped:", E_Pop)
        print("Nodes Expanded:", E_Exp)
        print("Nodes Generated:", E_Gen)
        print("Max Fringe Size:", Max_F_Size)
        if Cost_Est == -1:
            print("Solution not found within depth dep_limi")
        else:
            print("Solution Found at depth", Cost_Est)
            print("Steps:")
            initial_state_to_go = [initial_state_to_go[:3] , initial_state_to_go[3:6] , initial_state_to_go[6:]]
            Step_Count = 1
            Cost_Estimation = 0
            for Each_Value in path:
                Each_Value = Each_Value.title().strip()
                Position_Of_Zero = [None, None]
                
                for i in range(3):
                    for j in range(3):
                        if initial_state_to_go[i][j] == 0:
                            Position_Of_Zero = [ i, j]
                            break
                if Each_Value == "Left":
                    Temp_Cost = int(initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]-1])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Right")
                    initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]], initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]-1] = initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]-1], initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]]
                    #if status == "true" : print(initial_state_to_go)
                elif Each_Value == "Right":
                    Temp_Cost = int(initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]+1])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Left")
                    initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]], initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]+1] = initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]+1], initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]]
                    #if status == "true" : print(initial_state_to_go)
                elif Each_Value == "Up":
                    Temp_Cost = int(initial_state_to_go[Position_Of_Zero[0]-1][Position_Of_Zero[1]])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Down")
                    initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]], initial_state_to_go[Position_Of_Zero[0]-1][Position_Of_Zero[1]] = initial_state_to_go[Position_Of_Zero[0]-1][Position_Of_Zero[1]], initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]]
                    #if status == "true" : print(initial_state_to_go)
                elif Each_Value == "Down":
                    Temp_Cost = int(initial_state_to_go[Position_Of_Zero[0]+1][Position_Of_Zero[1]])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Up")
                    initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]], initial_state_to_go[Position_Of_Zero[0]+1][Position_Of_Zero[1]] = initial_state_to_go[Position_Of_Zero[0]+1][Position_Of_Zero[1]], initial_state_to_go[Position_Of_Zero[0]][Position_Of_Zero[1]]
                    #if status == "true" : print(initial_state_to_go)
                Step_Count = Step_Count + 1
            print("Final Cost :", Cost_Estimation)
        if Selected_Dump_Status=="true":
            file = open("Tracing Dumps", "w")
            file.writelines(tracing_data)
            file.close()
        
    elif Selected_Search == "ids":
        print("Iterative Deepening Search")
        from ids import ids_search
        First_Puzzle = []
        for x in Input_File_Read:
            First_Puzzle.extend(x)
        last_Puzzle = []
        for x in Goal_File_Read:
            last_Puzzle.extend(x)
        ids_search(First_Puzzle, last_Puzzle, Selected_Dump_Status)
        
        
    elif Selected_Search == "greedy":
        print("Greedy Search")
        from gs import greedy_search
        greedy_search(Input_File_Read, Goal_File_Read, Selected_Dump_Status)
        
    else:
        print("A Star Search")
        from asa import dfs_a_star
        nodes_popped, nodes_expanded, nodes_generated, max_fringe_size, cost, path, tracing_data = dfs_a_star(Input_File_Read, Goal_File_Read)
        print("Nodes Popped:", nodes_popped)
        print("Nodes Expanded:", nodes_expanded)
        print("Nodes Generated:", nodes_generated)
        print("Max Fringe Size:", max_fringe_size)
        if cost == -1:
            print("No solution found.")
        else:
            print("Solution found at depth", cost)
            Direction_Trace([Input_File_Read] + path[:], Selected_Dump_Status)
        if Selected_Dump_Status=="true":
            file = open("Tracing Dumps", "w")
            file.writelines(tracing_data)
            file.close()
        
else:
    print("Give Correct Arguments!")
