from queue import PriorityQueue

SIZE = 3

def Find_Zero(Instance_State):
    for Loop_i in range(SIZE):
        for j in range(SIZE):
            if Instance_State[Loop_i][j] == 0:
                return Loop_i, j

def uniform_cost_search(initial_state, goal_state, status):
    
    #
    tracing_data = "" + "Input Data ->\n" + str(initial_state) + "\noutput data ->\n" + str(goal_state) + "\n\n" + "Choosen Algorithm -> Uniform Cost Search\n" 
    
    Front_Node = PriorityQueue()
    Front_Node.put((0, initial_state))
    Visited_Node = set()
    Ins_Actions = {str(initial_state): []}
    Opping_Nodes = 0
    Expand_node = 0
    Generated_Nodes = 1
    Frienze_Size = 1
    
    #
    tracing_data = tracing_data + "\n" + "Starting Search"
    tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Opping_Nodes)
    tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Expand_node)
    tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Generated_Nodes)
    tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Frienze_Size) + "\n"
    
    while not Front_Node.empty():
        Final_Cost, Instance_State = Front_Node.get()
        Opping_Nodes += 1
        if Instance_State == goal_state:
            Step_Count = 1
            Cost_Estimation = 0
            
            #
            tracing_data = tracing_data + "\n" + "\n\nFinal Move ->"
            tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Opping_Nodes)
            tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Expand_node)
            tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Generated_Nodes)
            tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Frienze_Size)
            
            print("Nodes Popped:", Opping_Nodes)
            print("Nodes Expanded:", Expand_node)
            print("Nodes Generated:", Generated_Nodes)
            print("Max Fringe Size:", Frienze_Size)
            print("Solution Found at depth", len(Ins_Actions[str(Instance_State)]))
            print("Steps:")
            for Each_Value in Ins_Actions[str(Instance_State)]:
                Each_Value = Each_Value.title().strip()
                Position_Of_Zero = [None, None]
                for Loop_i in range(3):
                    for j in range(3):
                        if initial_state[Loop_i][j] == 0:
                            Position_Of_Zero = [ Loop_i, j]
                            break
                if Each_Value == "Left":
                    Temp_Cost = int(initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]-1])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Right")
                    initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]], initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]-1] = initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]-1], initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]]
                elif Each_Value == "Right":
                    Temp_Cost = int(initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]+1])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Left")
                    initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]], initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]+1] = initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]+1], initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]]
                elif Each_Value == "Up":
                    Temp_Cost = int(initial_state[Position_Of_Zero[0]-1][Position_Of_Zero[1]])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Down")
                    initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]], initial_state[Position_Of_Zero[0]-1][Position_Of_Zero[1]] = initial_state[Position_Of_Zero[0]-1][Position_Of_Zero[1]], initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]]
                elif Each_Value == "Down":
                    Temp_Cost = int(initial_state[Position_Of_Zero[0]+1][Position_Of_Zero[1]])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Up")
                    initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]], initial_state[Position_Of_Zero[0]+1][Position_Of_Zero[1]] = initial_state[Position_Of_Zero[0]+1][Position_Of_Zero[1]], initial_state[Position_Of_Zero[0]][Position_Of_Zero[1]]
                #if status == "true" : print(initial_state)
                Step_Count = Step_Count + 1
            print("Final Cost :", Cost_Estimation)
            
            #
            if status=="true":
                file = open("Tracing Dumps", "w")
                file.writelines(tracing_data)
                file.close()
            
            return
        
        #
        tracing_data = tracing_data + "\n" + "Current Node ->" + str(Instance_State)
        
        Visited_Node.add(str(Instance_State))
        blank_tile_i, blank_tile_j = Find_Zero(Instance_State)
        for move_i, move_j, action in [(-1, 0, "Up"), (1, 0, "Down"), (0, -1, "Left"), (0, 1, "Right")]:
            new_i = blank_tile_i + move_i
            new_j = blank_tile_j + move_j
            if 0 <= new_i < SIZE and 0 <= new_j < SIZE:
                new_state = [row[:] for row in Instance_State]
                new_state[blank_tile_i][blank_tile_j] = Instance_State[new_i][new_j]
                new_state[new_i][new_j] = 0
                
                tracing_data = tracing_data + "\n" + "- - - - - -Generated New State- - - - - - "
                tracing_data = tracing_data + "\n" + str(new_state)
                
                if str(new_state) not in Visited_Node:
                    new_cost = Final_Cost + 1
                    Front_Node.put((new_cost, new_state))
                    Generated_Nodes += 1
                    Ins_Actions[str(new_state)] = Ins_Actions[str(Instance_State)] + [action]
        Expand_node += 1
        Frienze_Size = max(Frienze_Size, Front_Node.qsize())
        
        #
        tracing_data = tracing_data + "\n" + "- - - - - -- - - - - - "
        tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Opping_Nodes)
        tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Expand_node)
        tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Generated_Nodes)
        tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Frienze_Size) + "\n"

