import copy

def Find_Blank(Main_Board):
    for i in range(3):
        for j in range(3):
            if Main_Board[i][j] == 0:
                return i, j

def Direction_Trace(solution, Selected_Dump_Status):
    solution = [ [x[:3],x[3:6],x[6:]] for x in solution ]
    Step_Counting = 1
    Length_Solution = len(solution)-1
    Total_Cost = 0
    for Temp_Index_value in range(Length_Solution):
        #if Selected_Dump_Status == "true":
            #print("Step ->", Step_Counting)
        first_zer_pos = Find_Blank(solution[Temp_Index_value])
        second_zer_pos = Find_Blank(solution[Temp_Index_value + 1])
        Temp_Cost = solution[Temp_Index_value][second_zer_pos[0]][second_zer_pos[1]]
        Total_Cost = Total_Cost + Temp_Cost
        if first_zer_pos[0] == second_zer_pos[0]:
            if first_zer_pos[1] > second_zer_pos[1]:
                print("\tMove", Temp_Cost, "Right")
            else:
                print("\tMove", Temp_Cost, "Left")
        else:
            if first_zer_pos[0] > second_zer_pos[0]:
                print("\tMove", Temp_Cost, "Down")
            else:
                print("\tMove", Temp_Cost, "Up")
        #if Selected_Dump_Status == "true":
                #print(solution[Temp_Index_value+1])
        Step_Counting = Step_Counting + 1
    print("Final Cost :", Total_Cost)

def ids_search(First_Puzzle, last_Puzzle, status):
    
    tracing_data = "" + "Input Data ->\n" + str(First_Puzzle) + "\noutput data ->\n" + str(last_Puzzle) + "\n\n" + "Choosen Algorithm -> Iterative Deepening Search\n" 


    Dep_Maxi = 0
    Opo_Nod = 0
    Exp_Nod = 0
    Gen_Nod = 0
    max_fringe_size = 0
    
    tracing_data = tracing_data + "\n" + "\n\nStarting Data ->"
    tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Opo_Nod)
    tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Exp_Nod)
    tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Gen_Nod)
    tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(max_fringe_size)
    
    while True:
        Visi_Nod = set()
        dep_Limi = Dep_Maxi + 1
        fringe = [(First_Puzzle, 0, [])]
        while fringe:
            state, cost, path = fringe.pop(0)
            Opo_Nod += 1
            if tuple(state) == tuple(last_Puzzle):
                
                tracing_data = tracing_data + "\n" + "\n\nFinal  Data ->"
                tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Opo_Nod)
                tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Exp_Nod)
                tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Gen_Nod)
                tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(max_fringe_size)
                
                print("Nodes Popped:", Opo_Nod)
                print("Nodes Expanded:", Exp_Nod)
                print("Nodes Generated:", Gen_Nod)
                print("Max Fringe Size:", max_fringe_size)
                print("Solution Found at depth", len(path))
                print("Steps:")
                Direction_Trace([First_Puzzle] + path[:], status)
                
                if status=="true":
                    file = open("Tracing Dumps", "w")
                    file.writelines(tracing_data)
                    file.close()
                
                return
            if tuple(state) in Visi_Nod:
                continue
            Visi_Nod.add(tuple(state))
            Exp_Nod = Exp_Nod + 1
            if len(path) < dep_Limi:
                Final_List_Of_Moves = []
                Index_of_Zero = state.index(0)
                
                tracing_data = tracing_data + "\n" + "New State generated ->" + str(state)
                tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Opo_Nod)
                tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Exp_Nod)
                tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Gen_Nod)
                tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(max_fringe_size)
                
                if Index_of_Zero % 3 != 0:
                    new_state = copy.deepcopy(state)
                    new_state[Index_of_Zero], new_state[Index_of_Zero - 1] = new_state[Index_of_Zero - 1], new_state[Index_of_Zero]
                    Final_List_Of_Moves.append(new_state)
                if Index_of_Zero % 3 != 2:
                    new_state = copy.deepcopy(state)
                    new_state[Index_of_Zero], new_state[Index_of_Zero + 1] = new_state[Index_of_Zero + 1], new_state[Index_of_Zero]
                    Final_List_Of_Moves.append(new_state)
                if Index_of_Zero // 3 != 0:
                    new_state = copy.deepcopy(state)
                    new_state[Index_of_Zero], new_state[Index_of_Zero - 3] = new_state[Index_of_Zero - 3], new_state[Index_of_Zero]
                    Final_List_Of_Moves.append(new_state)
                if Index_of_Zero // 3 != 2:
                    new_state = copy.deepcopy(state)
                    new_state[Index_of_Zero], new_state[Index_of_Zero + 3] = new_state[Index_of_Zero + 3], new_state[Index_of_Zero]
                    Final_List_Of_Moves.append(new_state)
                for move in Final_List_Of_Moves:
                    
                    tracing_data = tracing_data + "\n" + "Moves generated from states" + str(move)
                    
                    if tuple(move) not in Visi_Nod:
                        Gen_Nod += 1
                        fringe.append((move, cost + 1, path + [move]))
                        tracing_data = tracing_data + "\n" + "Node ->" + str(move) + "not in visited node, adding it"
                        tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Gen_Nod)
                        
            max_fringe_size = max(max_fringe_size, len(fringe))
        tracing_data = tracing_data + "\n" + "\n\nAfter Iteration ->"
        tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Opo_Nod)
        tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Exp_Nod)
        tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Gen_Nod)
        tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(max_fringe_size)+ "\n"    
        Dep_Maxi = Dep_Maxi + 1


