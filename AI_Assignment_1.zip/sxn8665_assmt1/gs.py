from queue import PriorityQueue

SIZE = 3

def Final_Zero(Current_State, tile):
    for i in range(SIZE):
        for j in range(SIZE):
            if Current_State[i][j] == tile:
                return i, j

def greedy_search(Your_Start_State, GOAL_STATE, Your_flag_Status):
    
    tracing_data = "" + "Input Data ->\n" + str(Your_Start_State) + "\noutput data ->\n" + str(GOAL_STATE) + "\n\n" + "Choosen Algorithm -> Greedy Search\n" 
    
    Front_Node = PriorityQueue()
    Front_Node.put((0, Your_Start_State))
    Visi_Node = set()
    Taken_Actions = {str(Your_Start_State): []}
    Pop_Nodes = 0
    Expand_node = 0
    Gen_Node = 1
    Frienge_Size = 1
    
    tracing_data = tracing_data + "\n" + "Starting Search"
    tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Pop_Nodes)
    tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Expand_node)
    tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Gen_Node)
    tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Frienge_Size)
    
    while not Front_Node.empty():
        _, Current_State = Front_Node.get()
        Pop_Nodes += 1
        if GOAL_STATE == Current_State:
            cost = len(Taken_Actions[str(Current_State)])
            print("Nodes Popped:", Pop_Nodes)
            print("Nodes Expanded:", Expand_node)
            print("Nodes Generated:", Gen_Node)
            print("Max Fringe Size:", Frienge_Size)
            print("Solution Found at depth", cost)
            print("Steps:")
            Step_Count = 1
            Cost_Estimation = 0
            for Each_Value in Taken_Actions[str(Current_State)]:
                Each_Value = Each_Value.title().strip()
                Position_Of_Zero = [None, None]
                for i in range(3):
                    for j in range(3):
                        if Your_Start_State[i][j] == 0:
                            Position_Of_Zero = [ i, j]
                            break
                if Each_Value == "Left":
                    Temp_Cost = int(Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]-1])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if Your_flag_Status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Right")
                    Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]], Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]-1] = Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]-1], Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]]
                    #if Your_flag_Status == "true" : print(Your_Start_State)
                elif Each_Value == "Right":
                    Temp_Cost = int(Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]+1])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if Your_flag_Status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Left")
                    Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]], Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]+1] = Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]+1], Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]]
                    #if Your_flag_Status == "true" : print(Your_Start_State)
                elif Each_Value == "Up":
                    Temp_Cost = int(Your_Start_State[Position_Of_Zero[0]-1][Position_Of_Zero[1]])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if Your_flag_Status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Down")
                    Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]], Your_Start_State[Position_Of_Zero[0]-1][Position_Of_Zero[1]] = Your_Start_State[Position_Of_Zero[0]-1][Position_Of_Zero[1]], Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]]
                    #if Your_flag_Status == "true" : print(Your_Start_State)
                elif Each_Value == "Down":
                    Temp_Cost = int(Your_Start_State[Position_Of_Zero[0]+1][Position_Of_Zero[1]])
                    Cost_Estimation = Cost_Estimation + Temp_Cost
                    #if Your_flag_Status == "true" : print("Step ->", Step_Count)
                    print("\tMove",Temp_Cost,"Up")
                    Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]], Your_Start_State[Position_Of_Zero[0]+1][Position_Of_Zero[1]] = Your_Start_State[Position_Of_Zero[0]+1][Position_Of_Zero[1]], Your_Start_State[Position_Of_Zero[0]][Position_Of_Zero[1]]
                    #if Your_flag_Status == "true" : print(Your_Start_State)
                Step_Count = Step_Count + 1
            print("Final Cost :", Cost_Estimation)
            
            if Your_flag_Status=="true":
                file = open("Tracing Dumps", "w")
                file.writelines(tracing_data)
                file.close()
            
            return
        Visi_Node.add(str(Current_State))
        tracing_data = tracing_data + "\n" + "Current State ->" + str(Current_State)
        tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Pop_Nodes)
        tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Expand_node)
        tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Gen_Node)
        tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Frienge_Size)
        tracing_data = tracing_data + "\n"
        blank_tile_i, blank_tile_j = Final_Zero(Current_State, 0)
        for move_i, move_j, action in [(-1, 0, "Up"), (1, 0, "Down"), (0, -1, "Left"), (0, 1, "Right")]:
            new_i = blank_tile_i + move_i
            new_j = blank_tile_j + move_j
            if 0 <= new_i < SIZE and 0 <= new_j < SIZE:
                new_state = [row[:] for row in Current_State]
                new_state[blank_tile_i][blank_tile_j] = Current_State[new_i][new_j]
                new_state[new_i][new_j] = 0
                
                tracing_data = tracing_data + "\n" + "New State Generated ->" + str(new_state)
                
                if str(new_state) not in Visi_Node:
                    h = sum(abs(i - goal_i) + abs(j - goal_j) for i, row in enumerate(new_state) for j, tile in enumerate(row) if tile != 0 for goal_i, goal_row in enumerate(GOAL_STATE) for goal_j, goal_tile in enumerate(goal_row) if goal_tile == tile)
                    Front_Node.put((h, new_state))
                    Taken_Actions[str(new_state)] = Taken_Actions[str(Current_State)] + [action]
                    Gen_Node += 1
                    
                    tracing_data = tracing_data + "\n" + str(new_state) + "Is not in visited nodes adding it" + str(Gen_Node)
                    tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Gen_Node)
                    tracing_data = tracing_data + "\n"
                    
        Expand_node += 1
        Frienge_Size = max(Frienge_Size, Front_Node.qsize())
        
        tracing_data = tracing_data + "\n" + "After Iteration"
        tracing_data = tracing_data + "\n" + "Total Nodes Popped ->" + str(Pop_Nodes)
        tracing_data = tracing_data + "\n" + "Total Expanded Nodes ->" + str(Expand_node)
        tracing_data = tracing_data + "\n" + "Total Nodes Generated ->" + str(Gen_Node)
        tracing_data = tracing_data + "\n" + "Maximum fringe Size -> " + str(Frienge_Size)
        tracing_data = tracing_data + "\n"


