Name:Satya Pradyumna Teja Nunna
UTA ID:1002028665

Programming language used: Python
version: Python 3.8

Assignment tasks are implemented in separate files,

Task-1 implemented in bnet_task_1.py

To run task 1 (learning the conditional probability tables):

Open the command prompt or terminal.
Change the directory to the folder containing the bnet.py file.
Run the following command: python bnet_task_1.py training_data.txt

Code Structure:
Define a function bnet_task_1(training_data_file) that takes the training data file as input and performs the following operations:
	-> Initialize the counts defaultdict. It is a dictionary of dictionaries, where the dictionary has a default integer value of 0. 
	This helps in counting the occurrences of each variable combination in the training data.
	-> Open the training data file and read its content line by line. For each line, extract the values of B, G, C, and F, 
	and update the counts defaultdict accordingly.
	-> Calculate the conditional probability tables P(B|G), P(G|C), and P(F|C) using the counts dictionary. 
	For each pair of variable values, divide the count of their co-occurrence by the count of the conditioning variable.
	
Task-2 implemented in bnet_task_2.py

To run task 2 (learning the conditional probability tables):

Open the command prompt or terminal.
Change the directory to the folder containing the bnet.py file.
Run the following command: python bnet_task_2.py training_data.txt <Bt> <Gt> <Ct> <Ft>

Code Structure:
Define a function bnet_task_2(training_data_file, B_input, G_input, C_input, F_input) that takes the training data file
and the input values for the binary variables B, G, C, and F as input arguments.
	-> Calculate the conditional probability tables P(B|G), P(G|C), and P(F|C) using the counts dictionary. 
	For each pair of variable values, divide the count of their co-occurrence by the count of the conditioning variable.
	-> Convert the input arguments for the binary variables to their corresponding binary values (0 or 1) 
	using the provided string format (e.g., "Bt" for B=true, "Bf" for B=false, etc.).
	-> Calculate the joint probability distribution (JPD) for the given input values using the chain rule 
	and the calculated conditional probability tables.
	
Task-3 implemented in bnet.py

To run task 3:
Open the command prompt or terminal.
Change the directory to the folder containing the bnet.py file.
Run the following command: python bnet.py training_data.txt <Bt> <Gt> given <Ff>

	-> Task is to calculate the conditional probabilities of binary variables B, G, C, and F using a Bayesian network and the provided training data. 
	The code can handle both queries with and without evidence variables.
	-> Calculate the conditional probability tables P(B|G), P(G|C), and P(F|C) using the counts dictionary. 
	For each pair of variable values, divide the count of their co-occurrence by the count of the conditioning variable.
	-> Define a helper function get_probability(variables) that takes the variable values as input and returns 
	the probability of the joint distribution using the calculated conditional probability tables.
	-> Convert the input query and evidence variables (if any) to their corresponding binary values using 
	the provided string format (e.g., "Bt" for B=true, "Bf" for B=false, etc.) and store them in dictionaries.
	-> Iterate through all possible combinations of the remaining variables not in the query or evidence variables. 
	For each combination, update the joint variables dictionary and calculate the probability using the helper function get_probability(). 
	Add this probability to the total_prob variable.
