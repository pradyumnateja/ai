import sys
from collections import defaultdict

def bnet_task_1(training_data_file):
    counts = defaultdict(lambda: defaultdict(int))
    
    with open(training_data_file, "r") as file:
        for line in file:
            B, G, C, F = map(int, line.strip().split())
            counts["BG"][B, G] += 1
            counts["B"][B] += 1
            counts["GC"][G, C] += 1
            counts["G"][G] += 1
            counts["CF"][C, F] += 1
            counts["C"][C] += 1

    # Compute conditional probability tables
    P_BG = {(b, g): counts["BG"][b, g] / counts["B"][b] for b in [0, 1] for g in [0, 1]}
    P_GC = {(g, c): counts["GC"][g, c] / counts["G"][g] for g in [0, 1] for c in [0, 1]}
    P_CF = {(c, f): counts["CF"][c, f] / counts["C"][c] for c in [0, 1] for f in [0, 1]}

    print("P(B given G):")
    for (b, g), p in P_BG.items():
        print("P(B={}|G={}) = {:.4f}".format(b, g, p))
    print("\nP(G given C):")
    for (g, c), p in P_GC.items():
        print("P(G={}|C={}) = {:.4f}".format(g, c, p))
    print("\nP(F given C):")
    for (c, f), p in P_CF.items():
        print("P(F={}|C={}) = {:.4f}".format(f, c, p))

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Invalid file input")
        sys.exit(1)
    file_name = sys.argv[1]
    bnet_task_1(sys.argv[1])