import sys
import itertools
from collections import defaultdict

def bnet(training_data_file, query_vars, evidence_vars=None):
    counts = defaultdict(lambda: defaultdict(int))
    
    with open(training_data_file, "r") as file:
        for line in file:
            B, G, C, F = map(int, line.strip().split())
            counts["BG"][B, G] += 1
            counts["B"][B] += 1
            counts["GC"][G, C] += 1
            counts["G"][G] += 1
            counts["CF"][C, F] += 1
            counts["C"][C] += 1

    # Compute conditional probability tables
    P_BG = {(b, g): counts["BG"][b, g] / counts["B"][b] for b in [0, 1] for g in [0, 1]}
    P_GC = {(g, c): counts["GC"][g, c] / counts["G"][g] for g in [0, 1] for c in [0, 1]}
    P_CF = {(c, f): counts["CF"][c, f] / counts["C"][c] for c in [0, 1] for f in [0, 1]}

    def get_probability(variables):
        B, G, C, F = variables
        return P_BG[B, G] * P_GC[G, C] * P_CF[C, F]

    # Convert input arguments to binary values
    var_mapping = {'B': 0, 'G': 1, 'C': 2, 'F': 3}
    query_vars = {var_mapping[x[0]]: int(x == f"{x[0]}t") for x in query_vars}
    if evidence_vars is not None:
        evidence_vars = {var_mapping[x[0]]: int(x == f"{x[0]}t") for x in evidence_vars}
        query_vars.update(evidence_vars)

    query_indices = [i for i in range(4) if i not in query_vars]
    total_prob = 0

    for values in itertools.product([0, 1], repeat=len(query_indices)):
        joint_vars = query_vars.copy()
        for i, value in zip(query_indices, values):
            joint_vars[i] = value
        total_prob += get_probability(tuple(joint_vars.values()))

    print(f"Probability = {total_prob:.6f}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Invalid input!")
        sys.exit(1)
    file_name = sys.argv[1]
    query_vars = sys.argv[2:]
    
    if "given" in query_vars:
        given_index = query_vars.index("given")
        evidence_vars = query_vars[given_index+1:]
        query_vars = query_vars[:given_index]
    else:
        evidence_vars = None

    bnet(file_name, query_vars, evidence_vars)