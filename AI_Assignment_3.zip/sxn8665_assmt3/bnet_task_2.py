import sys
from collections import defaultdict

def bnet_task_2(training_data_file, B_input, G_input, C_input, F_input):
    counts = defaultdict(lambda: defaultdict(int))
    
    with open(training_data_file, "r") as file:
        for line in file:
            B, G, C, F = map(int, line.strip().split())
            counts["BG"][B, G] += 1
            counts["B"][B] += 1
            counts["GC"][G, C] += 1
            counts["G"][G] += 1
            counts["CF"][C, F] += 1
            counts["C"][C] += 1

    # Compute conditional probability tables
    P_BG = {(b, g): counts["BG"][b, g] / counts["B"][b] for b in [0, 1] for g in [0, 1]}
    P_GC = {(g, c): counts["GC"][g, c] / counts["G"][g] for g in [0, 1] for c in [0, 1]}
    P_CF = {(c, f): counts["CF"][c, f] / counts["C"][c] for c in [0, 1] for f in [0, 1]}

    # Convert input arguments to binary values
    B = int(B_input == "Bt")
    G = int(G_input == "Gt")
    C = int(C_input == "Ct")
    F = int(F_input == "Ft")

    # Calculate the joint probability using the chain rule
    P_B = counts["B"][B] / sum(counts["B"].values())
    P_JPD = P_B * P_BG[B, G] * P_GC[G, C] * P_CF[C, F]

    # Calculated probability values
    print("P(B={}, G={}, C={}, F={}) = {:.6f}".format(B, G, C, F, P_JPD))

if __name__=="__main__":
    if len(sys.argv) != 6:
            print("Invalid command")
            sys.exit(1)
    file_name = sys.argv[1]
    bnet_task_2(file_name, sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])