#!/usr/bin/env python
# coding: utf-8

# In[1]:


def shortestCommonSuperstring(String_set):

        add_string = {}
        for previous, string1 in enumerate(String_set):
            add_string[(None, previous)] = string1
            for current, string2 in enumerate(String_set):
                if previous != current:
                    for idx in range(len(string2), -1, -1):
                        if string1.endswith(string2[:idx]):
                            add_string[(previous, current)] = string2[idx:]
                            break

        memo = {}
        def dfs(previous, visited):
            if (previous, visited) not in memo:
                best_len, best_idx = 0, None
                for current, s in enumerate(String_set):
                    bit = 1 << current
                    if not bit & visited:
                        cur_len = len(add_string[(previous, current)]) + dfs(current, visited ^ bit)[0]
                        if best_idx is None or cur_len < best_len:
                            best_len, best_idx = cur_len, current
                memo[(previous, visited)] = (best_len, best_idx)
            return memo[(previous, visited)]

        current = dfs(None, 0)[1]
        previous, visited, answer = None, 0, ""
        for _ in range(len(String_set)):
            answer += add_string[(previous, current)]
            visited |= 1 << current
            previous, current = current, memo[(current, visited)][1]
        return answer
    
String_set=["catg", "ctaagt", "gcta", "ttca", "atgcatc"]
# String_set=["geeks", "quiz", "for"]
result=shortestCommonSuperstring(String_set)
print(result)


# In[ ]:




