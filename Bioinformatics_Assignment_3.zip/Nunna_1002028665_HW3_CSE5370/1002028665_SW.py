#!/usr/bin/env python
# coding: utf-8

# In[ ]:


class Solution:
    def local_alignment(self, sequence_A: str, sequence_B: str, substitution: dict, gap_penalty: int) -> [tuple]:
        n,m=len(sequence_A),len(sequence_B)
        score_matrix = np.zeros((n+1, m+1))

        # Fill the scoring matrix using the Smith-Waterman algorithm
        for i in range(1, n+1):
            for j in range(1, m+1):
                ma= score_matrix[i-1][j-1] + (substitution[sequence_A[i-1]][sequence_B[j-1]] if sequence_A[i-1] == sequence_B[j-1] else substitution[sequence_A[i-1]][sequence_B[j-1]])
                d= score_matrix[i-1][j] + gap_penalty
                ins = score_matrix[i][j-1] + gap_penalty
                score_matrix[i][j] = max(0, ma,d,ins)
        print("")
        print(score_matrix)
        print("")
        
        # Traceback to find the optimal alignment(s)
        alignments = []
        max_score = np.max(score_matrix)
        for i in range(1, n+1):
            for j in range(1, m+1):
                if score_matrix[i][j] == max_score:
                    seq1_aligned = ""
                    seq2_aligned = ""
                    while score_matrix[i][j] > 0:
                        if score_matrix[i][j] == score_matrix[i-1][j-1] + (substitution[sequence_A[i-1]][sequence_B[j-1]] if sequence_A[i-1] == sequence_B[j-1] else substitution[sequence_A[i-1]][sequence_B[j-1]]):
                            seq1_aligned = sequence_A[i-1] + seq1_aligned
                            seq2_aligned = sequence_B[j-1] + seq2_aligned
                            i -= 1
                            j -= 1
                        elif score_matrix[i][j] == score_matrix[i-1][j] + gap_penalty:
                            seq1_aligned = sequence_A[i-1] + seq1_aligned
                            seq2_aligned = "-" + seq2_aligned
                            i -= 1
                        elif score_matrix[i][j] == score_matrix[i][j-1] + gap_penalty:
                            seq1_aligned = "-" + seq1_aligned
                            seq2_aligned = sequence_B[j-1] + seq2_aligned
                            j -= 1
                    alignments.append((seq1_aligned, seq2_aligned))

        return alignments


s=Solution()
seq_A = 'GTGGACT'
seq_B = 'ACTTAG'
gap = -2
match = 1
mismatch = -1

substitution = {}
nucleotides = ['A', 'C', 'G', 'T']
for nucleotide1 in nucleotides:
        substitution[nucleotide1] = {}
        for nucleotide2 in nucleotides:
            if nucleotide1 == nucleotide2:
                substitution[nucleotide1][nucleotide2] = match
            else:
                substitution[nucleotide1][nucleotide2] = mismatch

al = s.local_alignment(seq_A, seq_B, substitution, gap)
print()
print(al)

