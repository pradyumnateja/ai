#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# Define the input sequences and scoring parameters
class Solution:
    def global_alignment(self, sequence_A: str, sequence_B:str,substitution: dict, gap: int ) -> [tuple]:
    # Initialize the matrix and traceback matrix
        n_string, m_string = len(sequence_A), len(sequence_B)
        Dp = [[0] * (m_string + 1) for _ in range(n_string + 1)]
        Tback = [[""] * (m_string + 1) for _ in range(n_string + 1)]

        # Fill in the first row and column with gap penalties
        for i in range( n_string + 1):
            Dp[i][0] =  i *gap
        for j in range( m_string + 1):

            Dp[0][j] =  j *gap
        # Fill in the rest of the matrix and traceback matrix
        for i in range(1, n_string + 1):
            for j in range(1, m_string + 1):
                score1 = Dp[i - 1][j - 1] + substitution[sequence_A[i - 1]][sequence_B[j - 1]]
                score2 = Dp[i - 1][j] + gap
                score3 = Dp[i][j - 1] + gap
                max_score = max(score1, score2, score3)
                Dp[i][j] = max_score
                if score1 == max_score:
                    Tback[i][j] += "↖"
                if score2 == max_score:
                    Tback[i][j] += "↑"
                if score3 == max_score:
                    Tback[i][j] += "←"

        arr = substitution
        my_list = ['_']
        my_list1=['_','_']
        sa=list(sequence_A)
        sb=list(sequence_B)
        for char in sa:
            my_list.append(char)
        for char in sb:
            my_list1.append((char))

        
        # Traceback to find the alignments
        alignments = []
        stack = [(n_string, m_string, "", "")]
        while stack:
            i, j, seqA, seqB = stack.pop()
            if i == 0 and j == 0:
                alignments.append((seqA[::-1], seqB[::-1]))
            else:
                if i > 0 and j > 0 and "↖" in Tback[i][j]:
                    stack.append((i - 1, j - 1, seqA + sequence_A[i - 1], seqB + sequence_B[j - 1]))
                if i > 0 and "↑" in Tback[i][j]:
                    stack.append((i - 1, j, seqA + sequence_A[i - 1], seqB + "-"))
                if j > 0 and "←" in Tback[i][j]:
                    stack.append((i, j - 1, seqA + "-", seqB + sequence_B[j - 1]))
        for i, alignment in enumerate(alignments):
            print(f"Alignment {i+1}:")
            print(alignment[0])
            print("".join("|"if alignment[0][k] == alignment[1][k] else " " for k in range(len(alignment[0]))))
            print(alignment[1])
            print("\n")
        for i in my_list1:
            print("{:6s}".format(i),end=' ')
        print()
        for i, row in enumerate(Dp):
            print("{:6s}".format(my_list[i]),end=' ')
            for j, val in enumerate(row):
                element1 = str(val)
                element2 = Tback[i][j]
                #print(f"{element1}{element2}", end=' ')
                print("{:6s}".format(element1+element2),end=' ')
            print()
   
        aligned_tuples = []
        for alignment in alignments:
            aligned_tuples.append((alignment[1], alignment[0]))
            print()
        return aligned_tuples

s=Solution()
sequence_A = 'ACGT'
sequence_B = 'ACAT'
gap = -3
match = 1
mismatch = -6

substitution = {}
nucleotides = ['A', 'C', 'G', 'T']

for nucleotide1 in nucleotides:
    substitution[nucleotide1] = {}
    for nucleotide2 in nucleotides:
        if nucleotide1 == nucleotide2:
            substitution[nucleotide1][nucleotide2] = match
        else:
            substitution[nucleotide1][nucleotide2] = mismatch
al = s.global_alignment(sequence_A, sequence_B, substitution, gap)
print(al)

