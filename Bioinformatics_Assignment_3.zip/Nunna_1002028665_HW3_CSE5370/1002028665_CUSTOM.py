#!/usr/bin/env python
# coding: utf-8

# In[6]:


import numpy as np
substitution = {}

name="satyanunna"
n=set(name)
print(n)
print("")

for i in range(26):
    row = {}
    for j in range(26):
        if i == j :
            row[chr(ord('a') + j)] = 2  
        elif chr(ord('a') + j) in n:
            row[chr(ord('a') + j)] = 1
        else:
            row[chr(ord('a') + j)] = -1
    substitution[chr(ord('a') + i)] = row
print(np.matrix(substitution))

l=""

for i in range(ord('a'), ord('z')+1):
    l+=chr(i)
C = [[0 for j in range(len(l))] for i in range(len(l))]

for i in range(len(l)):
    for j in range(len(l)):
        C[i][j] = substitution[l[i]][l[j]]
print(C)
arr = C
my_list = ['_']
my_list1=[]
for char in range(ord('a'), ord('z')+1):
    my_list.append(chr(char)+" ")
    my_list1.append(chr(char))
for i in range(len(arr)):
    arr[i].insert(0, my_list1[i])
arr.insert(0, my_list)
a=(np.array(arr))
for row in a:
    for num in row:
        print("{:3s}".format(num),end=' ')
    print()
        


# In[ ]:




