package com.cts.mfpe.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.cts.mfpe.exception.IPTreatmentPackageNotFoundException;
import com.cts.mfpe.model.AilmentCategory;
import com.cts.mfpe.model.IPTreatmentPackage;
import com.cts.mfpe.model.PackageDetail;
import com.cts.mfpe.model.SpecialistDetail;
import com.cts.mfpe.repository.IPTreatmentPackageRepository;
import com.cts.mfpe.repository.PackageDetailRepository;
import com.cts.mfpe.repository.SpecialistDetailRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class IPTreatmentOfferingServiceImpl implements IPTreatmentOfferingService {

	@Autowired
	IPTreatmentPackageRepository treatmentPackRepository;

	@Autowired
	SpecialistDetailRepository specialistRepository;
	
	@Autowired
	PackageDetailRepository packageDetailRepository;
	
	@Override
	public SpecialistDetail storeSpl(SpecialistDetail sd) {
		
		SpecialistDetail sp=specialistRepository.save(sd);
		log.info("[New Specialist details:] "+ sp);
		return sp;
	}

	@Override
	public List<IPTreatmentPackage> findAllIPTreatmentPackages() {

		List<IPTreatmentPackage> treatmentPackages = treatmentPackRepository.findAll();
		log.info("[IPTreatmentPackage details:] "+ treatmentPackages);
		return treatmentPackages;
	}

	@Override
	public IPTreatmentPackage findIPTreatmentPackageByName(AilmentCategory ailment, String packageName) throws IPTreatmentPackageNotFoundException {

		IPTreatmentPackage treatmentPackage = treatmentPackRepository.findByName(ailment, packageName)
					.orElseThrow(() -> new IPTreatmentPackageNotFoundException("IP Treatment Package not found"));
		
		log.info("[IPTreatmentPackage ("+packageName+") detail:] "+ treatmentPackage);
		return treatmentPackage;
	}
	
	@Override
	public List<SpecialistDetail> sortSpecialist(AilmentCategory ailment){
		
		List<SpecialistDetail> lily=specialistRepository.findByAreaOfExpertise(ailment);
		log.info("[Area of Expertise:] "+ lily);
		return lily;
	}
	
	
	@Override
	public void DeleteSpecialist(int specialistId) {
		
		if(specialistRepository.findById(specialistId).isPresent()) {
			
			specialistRepository.deleteById(specialistId);
			
			
		}
		
		
	}

	@Override
	public List<SpecialistDetail> findAllSpecialists() {

		List<SpecialistDetail> specialists = specialistRepository.findAll();
		log.info("[Specialist details:] " + specialists);
		return specialists;
	}
	
	
	
	@Override
	public void UpdatePackage(int pid,PackageDetail packageDetail) {
		
		PackageDetail pd=packageDetailRepository.findById(pid).get();
		pd.setPid(packageDetail.getPid());
		pd.setTreatmentPackageName(packageDetail.getTreatmentPackageName());
		pd.setTestDetails(packageDetail.getTestDetails());
		pd.setCost(packageDetail.getCost());
		pd.setTreatmentDuration(packageDetail.getTreatmentDuration());
		packageDetailRepository.save(pd);
	}
	

}
