import numpy as np
import pandas as pd

from utils import extract_image_data, get_sentinel_data, 

crop_data = pd.read_csv("data/Crop_Location_Data.csv")


"""
    Sentinel 2 Data Extraction
    Extracting R,G,B Values from Sentinel-2 Data
"""
# Extract the images from the Sentinel 2 - Planetary Computer.
df = extract_image_data(crop_data)

# Save the NumPy arrays as a .npy file
np.save('data/image_data.npy', df['data'].values)

# Save the labels as a separate CSV file
df[['category']].to_csv('data/labels.csv', index=False)


""" 
    Sentinel 1 Data Extraction
    Extracting VV,VH Values from Sentinel-1 Data
"""

## Extracting VV,VH Values from Sentinel-1 Data
time_slice="2022-02-01/2022-06-30" # Harvest 1 Time Window
assests = ['vh','vv']
vh_vv = []

for coordinates in tqdm(crop_data['Latitude and Longitude']):
    vh_vv.append(get_sentinel_data(coordinates,time_slice,assests))
vh_vv_data = pd.DataFrame(vh_vv,columns =['vh','vv'])

def combine_datasets(dataset1,dataset2):
    data = pd.concat([dataset1,dataset2], axis=1)
    return data

crop_data = combine_datasets(crop_data,vh_vv_data)
crop_data.to_csv('data/Crop_Data_vv_vh.csv',index=False)