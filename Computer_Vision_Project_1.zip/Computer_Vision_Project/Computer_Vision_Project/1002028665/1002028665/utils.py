# Supress Warnings
import warnings
warnings.filterwarnings('ignore')

# Visualization
import matplotlib.pyplot as plt
from PIL import Image
import seaborn as sns
import xarray

# Data Science
import numpy as np
import pandas as pd

# Feature Engineering
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

# Machine Learning
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, accuracy_score,classification_report,confusion_matrix

# Planetary Computer Tools
import pystac
import pystac_client
import odc
import cv2
from odc.stac import stac_load
from odc.algo import to_rgba
from pystac_client import Client
from pystac.extensions.eo import EOExtension as eo
from odc.stac import stac_load
import planetary_computer as pc
pc.settings.set_subscription_key('bf4cc912fc6b47938d0d9bc61cb70820')

# Others
import os
import json


def extract_image_data(df: pd.DataFrame) -> pd.DataFrame:
    """Extracts the images from the Sentinel 2 - Planetary Computer."""

    # Define the time window
    time_window="2022-02-01/2022-06-30" # Harvest 1

    stac = pystac_client.Client.open("https://planetarycomputer.microsoft.com/api/stac/v1")

    # Define the pixel resolution for the final product
    resolution = 20  # meters per pixel 

    # Define the scale according to our selected crs, so we will use degrees
    scale = resolution / 111320.0 # degrees per pixel for CRS:4326

    # Initialize empty list to store image data and categories
    image_data_list = []


    print(f"Extracting data from Lat-Lon bounding box region...")
    for indx, row in df.iterrows():
        category = row['Class of Land']

        lat_long = row['Latitude and Longitude']
        lat_long = list(lat_long.split(','))
        lat = float(lat_long[0][1:])
        lon = float(lat_long[1][:-1])

        lat_long = (lat, lon) # Lat-Lon centroid location
        box_size_deg = 0.10 # Surrounding box in degrees

        # Calculate the Lat-Lon bounding box region
        min_lon = lat_long[1]-box_size_deg/2
        min_lat = lat_long[0]-box_size_deg/2
        max_lon = lat_long[1]+box_size_deg/2
        max_lat = lat_long[0]+box_size_deg/2
        bounds = (min_lon, min_lat, max_lon, max_lat) 

        search = stac.search(collections=["sentinel-2-l2a"], bbox=bounds, datetime=time_window)
        items = list(search.get_all_items())

        xx = stac_load(
            items,
            bands=["red", "green", "blue"],
            crs="EPSG:4326", # Latitude-Longitude
            resolution=scale, # Degrees
            chunks={"x": 2048, "y": 2048},
            dtype="uint16",
            patch_url=pc.sign,
            bbox=bounds
        )

    
        xx_array = xx.isel(time=6)[["red", "green", "blue"]].to_array()
        
        # Flatten the array and store it along with the category label
        flattened_array = xx_array.values.flatten()
        image_data_list.append({'data': flattened_array, 'category': category})

    # Convert the list to a Pandas DataFrame
    image_data_df = pd.DataFrame(image_data_list)

    print(f"\n...\nData Extracted!!!")

    return image_data_df

'''
def plot_image(xx: xarray.DataArray) -> None:
    # Plot the RGB image
    plt.figure(figsize=(10,10))
    plt.imshow(to_rgba(xx, bands=["red", "green", "blue"]))
    plt.show()
'''


def get_sentinel_data(latlong,time_slice,assets):
    '''
    Returns VV and VH values for a given latitude and longitude 
    Attributes:
    latlong - A tuple with 2 elements - latitude and longitude
    time_slice - Timeframe for which the VV and VH values have to be extracted
    assets - A list of bands to be extracted
    '''

    latlong=latlong.replace('(','').replace(')','').replace(' ','').split(',')
    bbox_of_interest = (float(latlong[1]) , float(latlong[0]), float(latlong[1]) , float(latlong[0]))
    time_of_interest = time_slice

    catalog = pystac_client.Client.open(
        "https://planetarycomputer.microsoft.com/api/stac/v1"
    )
    search = catalog.search(
        collections=["sentinel-1-rtc"], bbox=bbox_of_interest, datetime=time_of_interest
    )
    items = list(search.get_all_items())
    bands_of_interest = assests
    data = stac_load(
        [items[0]],
        crs = "EPSG:4326",
        resolution = 20 / 111320.0,
        chunks={"x": 2048, "y": 2048},
        patch_url=pc.sign, 
        bbox=bbox_of_interest
    ).isel(time=0)
    
    vh = data["vh"].astype("float").values.tolist()[0][0]
    vv = data["vv"].astype("float").values.tolist()[0][0]
    return vh,vv